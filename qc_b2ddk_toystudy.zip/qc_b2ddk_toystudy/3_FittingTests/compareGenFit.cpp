#include <cstdlib>
#include <iostream>
#include <vector>
#include <cstring>

#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauAbsCoeffSet.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TStyle.h"
#include "TTree.h"
#include "TROOT.h"
#include "THStack.h"
#include "TCanvas.h"
#include "TPad.h"
#include "TLegend.h"
#include "TH1F.h"
#include "buildResonanceModel.h"
#include "modelUtilities.h"
#include "resonInfo.h"

TH1F* plotDP(TString dataPath, TString histName, TString histLabel, int nbins, int lineCol, TString drawOpts){
    TFile* dataFile = new TFile(dataPath);
    TTree* dataTree = (TTree*)dataFile->Get("DecayTree");
    TH1F* dataDP = new TH1F(histName, histLabel, nbins, 3.6, 5.);
    dataTree->Draw("m12>>" + histName, "", drawOpts);
    dataDP->SetLineColor(lineCol);
    dataDP->SetLineWidth(6.0);
    return dataDP;
}

int main(){
    TString genSamplePath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-testSample.root";
    TString bestFitResultPath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-fitHist-153.root";
    TString truthToyPath = "output/temp/testTruthModel.root";
    TString fitToyPath = "output/temp/testFitModel.root";

    TString xlabel = "$m({D^{0}\\bar{D}^{0}})$ (\\text{GeV})";
    TString ylabel = "$m({\\bar{D}^{0}}K^{+})$ (\\text{GeV})";

    TString histLabel = ";" + xlabel + ";" + ylabel;

    int nevts = 4881;
    int nevtsToys = 1000000;
    int nbins = 50;

    // Constructing model with true amplitude parameters
    std::vector<resonInfo> trueModel;
    for (auto resID : fullResonanceList){
        trueModel.push_back(getDefaultResInfo(resID));
    }

    // Getting fit results from best fit
    std::vector<resonInfo> bestFitModel = readFitResults(bestFitResultPath);

    // Generating toy from true model
    genToyHist(trueModel, nevtsToys, truthToyPath, 1);

    // Generating toy from best fit model
    genToyHist(bestFitModel, nevtsToys, fitToyPath, 1);

    // Plotting distributions

    TH1F* genDP = plotDP(genSamplePath, "genDP", histLabel, nbins, 1, "P, E");
    TH1F* truthDP = plotDP(truthToyPath, "truthDP", histLabel, nbins, 2, "HIST");
    TH1F* fitDP = plotDP(fitToyPath, "fitDP", histLabel, nbins, 4, "HIST");

    // Normalising truth and best fit DP
    truthDP->Scale(genDP->Integral("width")/truthDP->Integral("width"));
    fitDP->Scale(genDP->Integral("width")/fitDP->Integral("width"));

    // Some cosmetic stuff...
    gROOT->ProcessLine(".x Visualisation/lhcbStyle.C");
    gStyle->SetLineWidth(4.);
    gStyle->SetHistTopMargin(0.1);
    gStyle->SetTitleOffset(1., "X");
    gStyle->SetTitleOffset(1.1, "Y");

    THStack* histStack = new THStack("hstack", ";" + xlabel + ";" + ylabel);
    TLegend* leg = new TLegend(0.01, 0.35, 00.99, 0.80);
    leg->SetLineColor(0);
    leg->SetTextFont(132);
    leg->SetTextSize(0.12);

    // Adding histograms to stack
    histStack->Add(genDP, "P, E");
    histStack->Add(truthDP, "HIST");
    histStack->Add(fitDP, "HIST");

    // Adding entries to legend
    leg->AddEntry(genDP, "Generated toy", "P, E");
    leg->AddEntry(truthDP, "True PDF", "L");
    leg->AddEntry(fitDP, "Fit PDF", "L");


    TCanvas* canvas = new TCanvas("canvas", "", 3000, 1800);
    TPad* pad1 = new TPad("p1", "p1", 0., 0.01, 0.80, 0.99);
    pad1->Draw();
    pad1->cd();
    histStack->Draw("NOSTACK");
    canvas->cd();
    TPad* pad2 = new TPad("p2", "p2", 0.81, 0.01, 0.99, 0.99);
    pad2->SetBorderSize(0);
    pad2->Draw();
    pad2->cd();
    leg->Draw();
    canvas->Update();
    canvas->SaveAs("test.png");
}