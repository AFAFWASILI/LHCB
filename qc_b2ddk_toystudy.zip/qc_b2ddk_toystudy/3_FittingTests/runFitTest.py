"""
Testing individual (i.e. not simultaneous fit to two samples) fits by performing fits to samples of varying sizes
"""
import numpy as np
import matplotlib.pyplot as plt
import mplhep
import awkward as ak
import uproot
import os
import shutil
import sys
import glob
import re
import pandas as pd
from warnings import simplefilter
from multiprocessing import Pool

def saveFitResults(fitFilesList, csvSavePath):
    """
    Extracts results from multiple test fits and saves them in a single csv
    """
    
    readColName = False
    colNames = np.array([])
    lines = []
    phaseNames = []

    if (len(fitFilesList) == 0):
        print("No fit results found, stopping")
    else:
        resultsDF = uproot.concatenate(fitFilesList, library='pd')
        resultsDF.to_csv(csvSavePath)
        """
        for file in uproot.iterate(fitFilesList):
            if (not readColName): # Reads in column names
                readColName = True
                colNames = file.fields
                phaseNames = [colName for colName in colNames if re.fullmatch("A[0-8]_Delta", colName)]
                colNames = ','.join(colNames)
            
            vals = ak.to_numpy(file)[0]
            for x in phaseNames:
                phaseVal = vals[x]
                newPhaseVal = phaseVal
                while (newPhaseVal > np.pi) or (newPhaseVal < -np.pi):
                    if (newPhaseVal > np.pi):
                        newPhaseVal -= 2*np.pi
                    elif (newPhaseVal < np.pi):
                        newPhaseVal += 2*np.pi
                #if (phaseVal != newPhaseVal):
                    #print(f"Shifted {x} from {phaseVal} to {newPhaseVal}")
                vals[x] = newPhaseVal
            vals = list(vals)
            lines.append(vals)
        
        print(f"Fit results saved to {csvSavePath}")
        np.savetxt(csvSavePath, lines, header=colNames, delimiter=',', comments='')
        """

def plot1DHist(arr, label, savepath, truthval = None):
    mplhep.styles.use("LHCb2")
    fig, ax = plt.subplots()
    plt.hist(arr, bins=20)
    plt.xlabel(f"Fit value - {label}")
    if not(truthval == None):
        plt.axvline(truthval, color='r', label=f'Truth val. = {round(truthval,2)}', zorder=4)
        plt.legend()
    plt.savefig(savepath) 
    plt.close()

def getFitParamList(fitResultsPath):
    fitResults = pd.read_csv(fitResultsPath)
    colNames = list(fitResults.columns)
    
    # Defining what parameters to plot - Currently only plotting the fitted amplitudes and phases
    ampParamNames = [x for x in colNames if re.fullmatch("A[0-9]_A", x)]
    ampParamNames += [x for x in colNames if re.fullmatch("A[0-9]_Delta", x)]
    return ampParamNames
    
def plotFitParams(fitResultsPath, plotSaveDir):
    fitResults = pd.read_csv(fitResultsPath)

    ampParamNames = getFitParamList(fitResultsPath)
    
    for param in ampParamNames:
        plotSavePath = plotSaveDir + f"/hist-{param}.png"
        plot1DHist(fitResults[param], param, plotSavePath, fitResults[param+"_True"][0])
    plot1DHist(fitResults["NLL"], "NLL", plotSaveDir + "/hist-NLL.png")

def setGlobalVars(evttype, nevts):
        saveTag = f"{evttype}-{nevts}evts"
        fitResultSaveFormat = f"output/FittingTests/{evttype}_Only/Tuples/{saveTag}-fitHist*.root"
        fitResultsPathList = glob.glob(fitResultSaveFormat)
        fitResultsCsvSavePath = f"output/FittingTests/{evttype}_Only/Results/{saveTag}-fitResults.csv"
        plotSaveDir = f"output/FittingTests/{evttype}_Only/Results/Plots/{saveTag}"
        
        return saveTag, fitResultSaveFormat, fitResultsPathList, fitResultsCsvSavePath, plotSaveDir

if __name__ == '__main__':
    
    # Test options
    #nevtsList = list(range(400, 2000, 400))
    #nevtsList += list(range(2000, 12000, 2000))
    #nevtsList = [100, 1000, 2000, 10000, 20000]
    nevtsList = [5000]
    correlated = False
    plotProjections = True
    nfits = 5
    maxRepeats = 5
    archiveResults = False

    evttype = None
    if correlated:
        evttype = "QC"
    elif not(correlated):
        evttype = "UC"
    else:
        sys.exit()
    
    fitParamList = []
    floatedParamList = []
    colNamePulls = ['nevents']
    valPulls = []
    colNameErrs = ['nevents']
    valErrs = []

    # Suppressing Pandas warnings
    simplefilter(action="ignore", category=pd.errors.PerformanceWarning)
    
    # Clearing old results directories
    for dir in ["output/FittingTests/QC_Only", "output/FittingTests/UC_Only"]:
        subdirs = ['Logs', 'Tuples', 'Results']
        for subdir in subdirs:
            # Creating subdirectories if they dont exist
            subdirPath = f"{dir}/{subdir}"
            if os.path.isdir(subdirPath):
                shutil.rmtree(subdirPath)
            os.mkdir(subdirPath)

    logsDir = f"output/FittingTests/{evttype}_Only/Logs"
    tuplesDir = f"output/FittingTests/{evttype}_Only/Tuples"
    resultsDir = f"output/FittingTests/{evttype}_Only/Results"
    
    
    
    
    def runTestFit(evttype, nevts):
        # Setting up naming convention
        saveTag = f"{evttype}-{nevts}evts"
        testSamplePath = f"{tuplesDir}/{saveTag}-testSample.root"
        genLogPath = f"{logsDir}/{saveTag}-genLog.log"
        
        # Generating test samples
        os.system(f"./bin/genSample {nevts} {testSamplePath} {tuplesDir}/{saveTag}- {int(correlated)} > {genLogPath} 2>&1")
        
        # Running repeated fits
        for i in range(nfits):
            fitSuccessful = False
            fitRepeat = 0
            fitSavePrefix = f"{tuplesDir}/{saveTag}-"
            while (not(fitSuccessful) and (fitRepeat < maxRepeats)):
                fitStatus = 0
                # Print debugging information and set up naming
                print(f"Running fit {i} repeat {fitRepeat}")
                fitLogPath = f"{logsDir}/{saveTag}-fit-{i}-rep{fitRepeat}.log"
                
                # Run fit
                os.system(f"./bin/singleSampleFitTest {testSamplePath} {fitSavePrefix} {i} {int(correlated)} > {fitLogPath} 2>&1")
                
                with open(fitLogPath) as logFile:
                    while True:
                        line = logFile.readline()
                        if "fitStatus" in line:
                            fitStatus = int(line.split(' ')[-1])
                            break
                
                if fitStatus == 3:
                    fitSuccessful = True
                else:
                    fitRepeat += 1
                    print(f"Fit failed, repeating fit {fitRepeat}/{maxRepeats}")
                print("")
                
                
        # Extracting results into .csv file
        # Setting up file paths
        saveTag, fitResultSaveFormat, fitResultsPathList, fitResultsCsvSavePath, plotSaveDir = setGlobalVars(evttype, nevts)
        
        # Creating plots directory if it doesnt exist
        if not(os.path.exists(plotSaveDir)):
            os.makedirs(plotSaveDir)
        saveFitResults(fitResultsPathList, fitResultsCsvSavePath) # Saving fit results to csv
        plotFitParams(fitResultsCsvSavePath, plotSaveDir) # Plotting fit parameter distribution
        

    argmap = [[evttype, x] for x in nevtsList]
    pool = Pool(4)
    results = pool.starmap(runTestFit, argmap)

    print("Finished fitting and saving results, making plots")
    
    
    for nevts in nevtsList:
        # Setting up file paths
        saveTag, fitResultSaveFormat, fitResultsPathList, fitResultsCsvSavePath, plotSaveDir = setGlobalVars(evttype, nevts)
        # Saving params names
        if (len(fitParamList) == 0):
            fitParamList = getFitParamList(fitResultsCsvSavePath)
        
        # Plotting fit results of best and worst fits (min and max NLL)
        fitResults = pd.read_csv(fitResultsCsvSavePath)
        NLLList = list(fitResults["NLL"])
        maxNLLInd = np.argmax(NLLList)
        minNLLInd = np.argmin(NLLList)
        
        print(f"{nevts} events : Best fit {minNLLInd} : Worst fit {maxNLLInd}")
        
        fitSamplePath = f"output/FittingTests/{evttype}_Only/Tuples/{saveTag}-testSample.root"
        bestFitPath = f"output/FittingTests/{evttype}_Only/Tuples/{saveTag}-fitHist-{minNLLInd}.root"
        worstFitPath = f"output/FittingTests/{evttype}_Only/Tuples/{saveTag}-fitHist-{maxNLLInd}.root"

        nominalInfoFile = open(f"output/FittingTests/{evttype}_Only/Results/{saveTag}-nominalFitInfo.txt", "w")
        nominalInfoFile.write(f"Best fit path: {bestFitPath} \n")
        nominalInfoFile.write(f"Worst fit path: {worstFitPath} \n")
        nominalInfoFile.close()
        
        if plotProjections:
            # Plotting projection of best and worst fits
            os.system(f"python Visualisation/plotDPProjection.py {bestFitPath} {fitSamplePath} {plotSaveDir+'/bestFit-'}")
            os.system(f"python Visualisation/plotDPProjection.py {worstFitPath} {fitSamplePath} {plotSaveDir+'/worstFit-'}")          
    
    if archiveResults:
        os.system("./saveResults.sh")
    