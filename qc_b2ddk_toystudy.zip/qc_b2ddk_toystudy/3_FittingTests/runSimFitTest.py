import os
import uproot
import mplhep
import numpy as np
import matplotlib.pyplot as plt
from glob import glob

if __name__ == "__main__":
    nevtsUCList = [1000]
    nevtsQCList = [1000, 2000, 3000, 4000, 5000]
    #nevtsQCList = [1000]
    #nevtsQC = np.arange(400, 2400, 400)
    nfits = 20
    regenerateToys = True
    
    testFitDir = "output/FittingTests/SimFit"
    testQCDir = f"{testFitDir}/QC"
    testUCDir = f"{testFitDir}/UC"
    testCoordDir = f"{testFitDir}/Coordinator"
    testResultsDir = f"{testFitDir}/Results"

    
    # Setting up output directories
    for dir in [testQCDir, testUCDir, testCoordDir] :
        if not(os.path.isdir(dir)):
            os.mkdir(dir)

        for subdir in [f"{dir}/{subdirLabel}" for subdirLabel in ["Logs", "Tuples"]]:
            if not(os.path.isdir(subdir)):
                os.mkdir(subdir)
                #print(subdir)
    
    if not(os.path.isdir(testResultsDir)):
        os.mkdir(testResultsDir)
        
    if not(os.path.isdir(f"{testResultsDir}/Plots")):
        os.mkdir(f"{testResultsDir}/Plots")
                
    # Generating toy data for fit
    for nevts in nevtsUCList:
        samplePath = f"{testUCDir}/Tuples/UC-{nevts}evts-testSample.root"
        sampleGenLogPath = f"{testUCDir}/Logs/UC-{nevts}-testSample.log"
        if regenerateToys or not(os.path.exists(samplePath)):
            os.system(f"./bin/genSample {nevts} {samplePath} {testUCDir}/Tuples/ 0 1 > {sampleGenLogPath} 2>&1")
        
    for nevts in nevtsQCList:
        samplePath = f"{testQCDir}/Tuples/QC-{nevts}evts-testSample.root"
        sampleGenLogPath = f"{testQCDir}/Logs/QC-{nevts}-testSample.log"
        if regenerateToys or not(os.path.exists(samplePath)):
            os.system(f"./bin/genSample {nevts} {samplePath} {testQCDir}/Tuples/ 1 1 > {sampleGenLogPath} 2>&1")
    
    
    # Running simultaneous fit
    for nevtsUC in nevtsUCList:
        fitErr_A1_A = []
        fit_A1_A = []
        
        fitErr_A3_A = []
        fit_A3_A = []
        for nevtsQC in nevtsQCList:
            samplePathUC = f"{testUCDir}/Tuples/UC-{nevtsUC}evts-testSample.root"
            samplePathQC = f"{testQCDir}/Tuples/QC-{nevtsQC}evts-testSample.root"
            saveTag = f"UC{nevtsUC}evts-QC{nevtsQC}evts"
            print(f"Performing joint fit with {nevtsUC} uncorrelated events, {nevtsQC} correlated events")
            os.system(f"python 2_JointLikelihoodFit/runSimFit.py {samplePathUC} {samplePathQC} {testFitDir} {saveTag} --nfits={nfits}")
            
            # Coordinator output tuples fine for fits where constFactor = 1.
            # When performing a simultaneous fit to flavour and CP tagged samples (i.e. models where parameters are related by constFactor)
            # Read fit results from flavour-tagged sample as they contain the unscaled parameter values
            # This workaround is needed because Laura++ overwrites the saved value with the last 
            # value finalised by the fit, leading to CP tagged fit results overwriting the flavour
            # tagged fit results in the coordinator tuple depending on the order in which the 
            # fits are finalised
            #coordResultsList = glob(f"{testCoordDir}/Tuples/{saveTag}-fit*")
            coordResultsList = glob(f"{testUCDir}/Tuples/{saveTag}-fit*")
            coordResultsList = [file + ":fitResults" for file in coordResultsList]
            coordNLLDict = {}
            for result in coordResultsList:
                coordNLLDict[result] = list(uproot.open(result)["NLL"].array(library='np'))[0]
            bestFitFile = min(coordNLLDict, key=coordNLLDict.get)[:-11]
            worstFitFile = max(coordNLLDict, key=coordNLLDict.get)[:-11]
            
            nominalFitFile = open(f"{testResultsDir}/{saveTag}-nominalFit.txt", "w")
            nominalFitFile.write(f"Best fit: {bestFitFile}\n")
            nominalFitFile.write(f"Worst fit: {worstFitFile}\n")
            nominalFitFile.close()            
                            
            fitResults = uproot.open(bestFitFile + ":fitResults").arrays(library='pd')
            fitErr_A1_A.append(fitResults['A1_A_Error'][0])
            fit_A1_A.append(fitResults['A1_A'][0])
            fitErr_A3_A.append(fitResults['A3_A_Error'][0])
            fit_A3_A.append(fitResults['A3_A'][0])
            
            # Plotting projection
            nevtsPlotsDir = f"{testResultsDir}/Plots/{saveTag}"
            
            if not(os.path.isdir(nevtsPlotsDir)):
                os.mkdir(nevtsPlotsDir)
                
            os.system(f"python Visualisation/plotDPProjectionSimFit.py {bestFitFile} {samplePathUC} {samplePathQC} {nevtsPlotsDir}/bestFit")
        
        
        # Plotting parameter error variation as function of QC sample size
        mplhep.styles.use("LHCb2")
        fig, ax = plt.subplots()
        plt.scatter(nevtsQCList, fitErr_A1_A)
        plt.ylabel("A1_A_Error (Nominal fit)")
        plt.xlabel("Num. QC events")
        plt.savefig(f"{testResultsDir}/Plots/UC-{nevtsUC}-A1_A-paramErrVar.png")
        plt.close()
        
        fig, ax = plt.subplots()
        plt.scatter(nevtsQCList, fit_A1_A)
        plt.errorbar(nevtsQCList, fit_A1_A, yerr=fitErr_A1_A, fmt='none')
        plt.ylabel("A1_A (Nominal fit)")
        plt.xlabel("Num. QC events")
        plt.savefig(f"{testResultsDir}/Plots/UC-{nevtsUC}-A1_A-paramValVar.png")
        plt.close()
    
        mplhep.styles.use("LHCb2")
        fig, ax = plt.subplots()
        plt.scatter(nevtsQCList, fitErr_A3_A)
        plt.ylabel("A3_A_Error (Nominal fit)")
        plt.xlabel("Num. QC events")
        plt.savefig(f"{testResultsDir}/Plots/UC-{nevtsUC}-A3_A-paramErrVar.png")
        plt.close()
        
        fig, ax = plt.subplots()
        plt.scatter(nevtsQCList, fit_A3_A)
        plt.errorbar(nevtsQCList, fit_A3_A, yerr=fitErr_A3_A, fmt='none')
        plt.ylabel("A3_A (Nominal fit)")
        plt.xlabel("Num. QC events")
        plt.savefig(f"{testResultsDir}/Plots/UC-{nevtsUC}-A3_A-paramValVar.png")
        plt.close()
    
    
    