#ifndef RESONINFO_STRUCT
#define RESONINFO_STRUCT

#include "LauAbsResonance.hh"
#include "TString.h"
#include <cmath>

struct resonInfo {
    TString resName = "DefaultName";
    LauAbsResonance::LauResonanceModel resType = LauAbsResonance::RelBW;
    Double_t resAmp = 1.;
    Double_t resPhase = 0.;
    Double_t resFitFrac = 0.;
    Int_t resPairAmpInt = 0;
    Int_t resID = -1;
    Bool_t fixResParams = kFALSE;
    Bool_t secondStage = kFALSE;
};

#endif