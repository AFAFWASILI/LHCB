#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>

#include "buildResonanceModel.h"
#include "resonInfo.h"
#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TTree.h"
#include "TTreeReader.h"

std::vector<resonInfo> readFitResults(TString fitResultPath, std::vector<int> fullResonanceList = fullResonanceList, int exptNum = 0){
    // Function for reading in fit results to a vector
    // Can change resonance model by passing in another
    // Returns a vector containing 3 vectors in the following order: magnitude, phase, fit fraction
    TFile* fitFile = new TFile(fitResultPath);
    std::vector<Double_t> fitAmp;
    std::vector<Double_t> fitPhase;
    for (int i = 0; i < fullResonanceList.size(); i++){
        TString ampName = "A" + std::to_string(i) + "_A";
        TString phaseName = "A" + std::to_string(i) + "_Delta";

        TTreeReader treeReader("fitResults", fitFile);
        TTreeReaderValue<int> fitExptReader(treeReader, "iExpt");
        TTreeReaderValue<Double_t> fitAmpReader(treeReader, ampName);
        TTreeReaderValue<Double_t> fitPhaseReader(treeReader, phaseName);
        while (treeReader.Next()){
            if (*fitExptReader == exptNum){ // If internal experiment number is specified, make sure to only read the specified one
                fitAmp.push_back(*fitAmpReader);
                fitPhase.push_back(*fitPhaseReader);
            }
        }
    }
    std::vector<resonInfo> modelVec; // Fit model represented by a vector of resonInfo of the individual components with magnitude, phase and fit fractions obtained from fit

    // Storing resonance magnitude and phase from fit into a resonInfo struct
    for (int i = 0; i < fullResonanceList.size(); i++){
        resonInfo resInfo = getDefaultResInfo(fullResonanceList[i]);
        resInfo.resAmp = fitAmp[i];
        resInfo.resPhase = fitPhase[i];
        modelVec.push_back(resInfo);
    }
    return modelVec;
}

void genToyHist(std::vector<resonInfo> resInfoVec, int nevts, TString savePath, int ntoys = 1){
    // Setting up fit model
    LauSimpleFitModel* fitModel = buildIsobarModel(resInfoVec);

    // Generating toy
    LauParameter *nSigEvents = new LauParameter("signalEvents", nevts, -1000.0, nevts, kTRUE);
    fitModel->setNSigEvents(nSigEvents);
    fitModel->setNExpts(ntoys, 0, kFALSE);
    fitModel->useAsymmFitErrors(kFALSE);
    fitModel->useRandomInitFitPars(kTRUE);
    fitModel->doPoissonSmearing(kFALSE);
    fitModel->doEMLFit(false);
    fitModel->run("gen", savePath, "DecayTree", "", "");
    delete fitModel;
}