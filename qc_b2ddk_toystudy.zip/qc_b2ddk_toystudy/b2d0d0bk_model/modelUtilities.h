#ifndef MODELUTILITIES_H
#define MODELUTILITIES_H

#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>

#include "buildResonanceModel.h"
#include "resonInfo.h"
#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TTree.h"

std::vector<resonInfo> readFitResults(TString fitResultPath, std::vector<int> fullResonanceList = fullResonanceList, int exptNum = 0);

void genToyHist(std::vector<resonInfo> resInfoVec, int nevts, TString savePath, int ntoys = 1);

#endif