#ifndef BUILDRESONANCEMODEL_H
#define BUILDRESONANCEMODEL_H

#include <cstdlib>
#include <iostream>
#include <vector>
#include <cmath>

#include "resonInfo.h"

#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauVetoes.hh"

#include "TFile.h"
#include "TString.h"
#include "TTree.h"

extern const std::vector<int> fullResonanceList;
extern const std::vector<int> fitResonanceList;
extern const std::vector<int> suppressedResonanceList;
extern const std::vector<int> enhahncedResonanceList;
extern const std::vector<int> fixedResList;
extern const std::vector<int> secondStageList;

resonInfo getDefaultResInfo(const int resonanceKey);

double getAmpFactor(int resInd);

std::vector<double> computeAmpFactors();

std::vector<double> computeAmpFactors(std::vector<int> resIndList);

LauAbsCoeffSet* addResonance(LauIsobarDynamics* sigModel, resonInfo resInfo, bool fixMass, bool fixWidth);

std::vector<LauAbsCoeffSet*>  addUncorrelatedResonances(LauIsobarDynamics* sigModel, std::vector<int> resonanceList, bool fixMass, bool fixWidth);

std::vector<LauAbsCoeffSet*>  addUncorrelatedResonances(LauIsobarDynamics* sigModel, std::vector<resonInfo> resonanceList, bool fixMass, bool fixWidth);

resonInfo getCorrelatedInfo(resonInfo resInfo);

LauSimpleFitModel* buildIsobarModel(std::vector<resonInfo> resInfoVec);

std::vector<resonInfo> changeNormalisation(std::vector<resonInfo> resModel, int newNormInd, int currentNormInd);
#endif