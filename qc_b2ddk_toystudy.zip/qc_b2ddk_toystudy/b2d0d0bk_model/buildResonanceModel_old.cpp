#include <cstdlib>
#include <iostream>
#include <vector>
#include <algorithm>

#include "resonInfo.h"
#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TTree.h"

// BW radius (Blatt-Weisskopf barrier factors not Breit-Wigner)

Double_t _bwRadius_parent = 4.0;  // typical values used in other analyses
Double_t _bwRadius_res_charmonia = 4.0;
Double_t _bwRadius_res_charm = 4.0;

/*
Resonance list defined with non-suppressed resonances at start of array so that the same index of the correlated and uncorrelated
resonance list internal to Laura++ corresponds to the same resonances until we reach the suppressed resonances.

This is necessary because Laura++ seems to require the indices to match up in order for it to recognise them to be the same (or related) parameter

The resonance indices correspond to the following resonances:
2 - chi_c2_2P - Used as normalisation mode
38 - chi_c0_2P
7 - Ds*+_2_2573
8 - Ds*+_1_2700
1 - psi_3770
3 - psi_4040
4 - psi_4160
5 psi_4415
*/

//std::vector<int> fullResonanceList{ 2, 38, 6, 7, 8, 1, 3, 4, 5 }; // List of resonances to include in model - Original resonance model
std::vector<int> fullResonanceList{ 2, 38, 7, 8, 1, 3, 4, 5 }; // List of resonances to include in model - With Ds*+_0(2317) resonance removed as it is not in kinematic bounds
//std::vector<int> fullResonanceList{1, 4, 7, 8, 33};
std::vector<int> fitResonanceList{ 2, 38, 8, 1 ,3, 4, 5}; // List of resonance to include in fit model
std::vector<int> suppressedResonanceList{ 1, 3, 4, 5 }; // List of suppressed resonances (i.e. in the case of a C=+1 correlated sample, this corresponds to C=-1 resonances and vice-versa)
std::vector<int> enhancedResonanceList{ 2, 38 }; // List of enhanced resonances (i.e C=+1 resonances in a C=+1 correlated sample)
std::vector<int> fixedResList = { 2 };
std::vector<int> secondStageList = { };

resonInfo getDefaultResInfo(const int resonanceKey) {
    // 
    resonInfo resInfo;
    resInfo.resID = resonanceKey;
    
    // Fix resonance if specified in fixedResList
    if(std::find(fixedResList.begin(), fixedResList.end(), resonanceKey) != fixedResList.end()){
        resInfo.fixResParams = kTRUE;
    } else {
        resInfo.fixResParams = kFALSE;
    }

    // Set to second stage in two-stage fit if specified to be so
    if (std::find(secondStageList.begin(), secondStageList.end(), resonanceKey) != secondStageList.end()){
        resInfo.secondStage = kTRUE;
    } else {
        resInfo.secondStage = kFALSE;
    }
    switch (resonanceKey) {
            /* #region 'Standard' anti-D0 D0 resonances */
            case 1:
                resInfo.resName = "psi(3770)";
                resInfo.resAmp = 1.589434;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            case 2:
                resInfo.resName = "chi_c2(2P)";
                resInfo.resAmp = 1.0;
                resInfo.resPhase = 0;
                resInfo.resPairAmpInt = 3;
                break;
            case 3:
                resInfo.resName = "psi(4040)";
                resInfo.resAmp = 0.863721;
                resInfo.resPhase = 0.78348;
                resInfo.resPairAmpInt = 3;
                break;
            case 4:
                resInfo.resName = "psi(4160)";
                resInfo.resAmp = 0.951593;
                resInfo.resPhase = 0.022106;
                resInfo.resPairAmpInt = 3;
                break;
            case 5:
                resInfo.resName = "psi(4415)";
                resInfo.resAmp = 1.09381;
                resInfo.resPhase = -2.38900;
                resInfo.resPairAmpInt = 3;
                break;
            case 38:
                resInfo.resName = "chi_c0(2P)";
                resInfo.resAmp = 0.731623;
                resInfo.resPhase = 1.38481;
                resInfo.resPairAmpInt = 3;
                break;
            /* #endregion */

            /* #region 'Standard' D0 K+ resonances */
            case 6:
                resInfo.resName = "Ds*+_0(2317)";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;

            case 7:
                resInfo.resName = "Ds*+_2(2573)";
                resInfo.resAmp = 0.024;
                resInfo.resPhase = -1.077;
                resInfo.resPairAmpInt = 1;
                break;

            case 8:
                resInfo.resName = "Ds*+_1(2700)";
                resInfo.resAmp = 1.135;
                resInfo.resPhase = 0.546;
                resInfo.resPairAmpInt = 1;
                break;
            case 9:
                resInfo.resName = "Ds*+_1(2700)_BW2";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 10:
                resInfo.resName = "Ds*+_1(2700)_BW3";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 11:
                resInfo.resName = "Ds*+_1(2700)_BW5";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 12:
                resInfo.resName = "Ds*+_1(2700)_BW6";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 13:
                resInfo.resName = "Ds*+_1(2860)";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 14:
                resInfo.resName = "Ds*+_3(2860)";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            /* #endregion */

            /* #region New anti-D0 D0 resonances */
            case 15:
                resInfo.resName = "X3915_S";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            case 16:
                resInfo.resName = "X3915_D";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            case 17:
                resInfo.resName = "DDK_DD_S_0";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            case 18:
                resInfo.resName = "DDK_DD_P_0";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            case 19:
                resInfo.resName = "DDK_DD_D_0";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            case 20:
                resInfo.resName = "DDK_DD_F_0";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 3;
                break;
            /* #endregion */

            /* #region New D0 K resonances */
            case 21:
                resInfo.resName = "DDK_D0Kp_S_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 22:
                resInfo.resName = "DDK_D0Kp_P_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 23:
                resInfo.resName = "DDK_D0Kp_D_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 24:
                resInfo.resName = "DDK_D0Kp_F_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            /* #endregion */

            /* #region New anti-D0 K resonances */
            case 25:
                resInfo.resName = "DDK_D0barKp_S_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 26:
                resInfo.resName = "DDK_D0barKp_P_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 28:
                resInfo.resName = "DDK_D0barKp_F_+";
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            /* #endregion */

            /* #region Non-resonant candidates */
            case 29:
                resInfo.resName = "NonReson";
                resInfo.resType = LauAbsResonance::FlatNR;
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 0;
                break;
            case 30: // Exponential NR component based on values from BaBar B+ to D0 D0bar K+ study
                resInfo.resName = "BelleNR";
                resInfo.resType = LauAbsResonance::BelleNR;
                resInfo.resAmp = 11.53571;
                resInfo.resPhase = -0.364059;
                resInfo.resPairAmpInt = 1;
                break;
            case 31:
                resInfo.resName = "BelleNR_Swave+";
                resInfo.resType = LauAbsResonance::BelleNR;
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 32:
                resInfo.resName = "BelleNR_Pwave+";
                resInfo.resType = LauAbsResonance::BelleNR;
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 1;
                break;
            case 33:
                resInfo.resName = "BelleNR+";
                resInfo.resType = LauAbsResonance::BelleNR;
                resInfo.resAmp = 3.2;
                resInfo.resPhase = -0.364059;
                resInfo.resPairAmpInt = 1;
                break;
            case 34:
                resInfo.resName = "BabarNR+";
                resInfo.resType = LauAbsResonance::FlatNR;
                resInfo.resAmp = 1.41993;
                resInfo.resPhase = -0.782938;
                resInfo.resPairAmpInt = 0;
                break;
                /* #endregion */
        }
    if (resInfo.resName == "DefaultName") {
        std::cout << "ERROR in getDefaultResInfo : Resonance not defined for resonanceKey = " << resonanceKey << std::endl;
        exit(EXIT_FAILURE);
    } else {
        return resInfo;
    }
    }

double getAmpFactor(int resInd){
    // Gets amplitude factor for a resonance given its resonance ID
    if (std::find(enhancedResonanceList.begin(), enhancedResonanceList.end(), resInd) != enhancedResonanceList.end()) { // If resInd corresponds to an enhanced resonance
        return 1.;
    } else if (std::find(suppressedResonanceList.begin(), suppressedResonanceList.end(), resInd) != suppressedResonanceList.end()) {// If resInd corresponds to a suppressed resonance
        return 0.;
    } else { // If resInd corresponds to an unsuppressed resonance (i.e. not D0D0b). Divide amplitude by sqrt(2) due to assumption that the fit is normalised to an enhanced resonance - Might change later
        return 1/sqrt(2);
    }
}

std::vector<double> computeAmpFactors(){
    // Computes the list of factors with which to multiply the uncorrelated factors to obtain the effective correlated amplitude
    std::vector<double> ampFactors;

    int n = fullResonanceList.size();
    for (int i = 0; i < n; i++){
        int resInd = fullResonanceList[i];
        ampFactors.push_back(getAmpFactor(resInd));
    }

    return ampFactors;
}

std::vector<double> computeAmpFactors(std::vector<int> resIndList){
    // Computes the list of factors with which to multiply the uncorrelated factors to obtain the effective correlated amplitude
    std::vector<double> ampFactors;

    int n = resIndList.size();
    for (int i = 0; i < n; i++){
        int resInd = resIndList[i];
        ampFactors.push_back(getAmpFactor(resInd));
    }

    return ampFactors;
}

LauAbsCoeffSet* addResonance(LauIsobarDynamics* sigModel, resonInfo resInfo, bool fixMass, bool fixWidth){
    // Adds a single resonance with parameters given in resInfo
    LauAbsResonance* reson(0);
    LauMagPhaseCoeffSet* resParams;
    Int_t resonanceKey = resInfo.resID;

    if (resonanceKey == -1){ // Checking resInfo refers to a valid resonance
        std::cout << "ERROR in addResonance : Invalid resonance ID" << std::endl;
        exit(EXIT_FAILURE);
    } else {
        // Adding resonance using information from resInfo
        resParams = new LauMagPhaseCoeffSet(resInfo.resName, resInfo.resAmp, resInfo.resPhase, resInfo.fixResParams, resInfo.fixResParams);
        reson = sigModel->addResonance(resInfo.resName, resInfo.resPairAmpInt, resInfo.resType);
        
        // Fixing mass and width
        reson->fixMass(fixMass);
        reson->fixWidth(fixWidth);

        // Additional configuration of resonances
        switch (resonanceKey) {
            /* #region 'Standard' anti-D0 D0 resonances */
            case 1:
                    // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                // PN: values from D- D+ K model. It must effectively fix the resonance mass, width, spin. I am not sure if the Gaussian Constraints for the fit are still applied once you change the mass and width
                reson->changeResonance(3.77799, 0.0275107, 1);
                break;

            case 2:
                // Using chi_c2 as normalisation mode
                reson->getMassPar()->addGaussianConstraint(3.92615, 0.00228685);  // the arguments are the central value and uncertainty from the external measurement
                reson->getWidthPar()->addGaussianConstraint(0.0337151, 0.00637956);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                // PN: values from D- D+ K model. It must effectively fix the resonance mass, width, spin. I am not sure if the Gaussian Constraints for the fit are still applied once you change the mass and width
                reson->changeResonance(3.92615, 0.0337151, 2);
                break;

            case 3:
                reson->getMassPar()->addGaussianConstraint(4.039, 0.001);
                reson->getWidthPar()->addGaussianConstraint(0.080, 0.010);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                reson->changeResonance(4.03901, 0.074246, 1);
                break;

            case 4:
                reson->getMassPar()->addGaussianConstraint(4.191, 0.005);
                reson->getWidthPar()->addGaussianConstraint(0.070, 0.010);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                // PN: values from D- D+ K model. It must effectively fix the resonance mass, width, spin. I am not sure if the Gaussian Constraints for the fit are still applied once you change the mass and width
                reson->changeResonance(4.19205, 0.0727848, 1);
                break;

            case 5:
                reson->getMassPar()->addGaussianConstraint(4.421, 0.004);
                reson->getWidthPar()->addGaussianConstraint(0.062, 0.020);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                // PN: values from D- D+ K model. It must effectively fix the resonance mass, width, spin. I am not sure if the Gaussian Constraints for the fit are still applied once you change the mass and width
                reson->changeResonance(4.42312, 0.106106, 1);
                break;

            case 38: {
                // PN: note, no Gaussian constraint seen in the D- D+ K model....
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                // PN: values from D- D+ K model. It must effectively fix the resonance mass, width, spin. I am not sure if the Gaussian Constraints for the fit are still applied once you change the mass and width
                reson->changeResonance(3.92394, 0.0169614, 0);

                break;
            }
            /* #endregion */

            /* #region 'Standard' D0 K+ resonances */
            case 6:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;

            case 7:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;

            case 8:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 9:

                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 10:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 11:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 12:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 13:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 14:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            /* #endregion */

            /* #region New anti-D0 D0 resonances */
            case 15:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                break;
            case 16:
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                break;
            case 17:
                reson->getWidthPar()->valueAndRange(0.025, 0.005, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                break;
            case 18:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                break;
            case 19:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                break;
            case 20:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charmonia, _bwRadius_parent);
                break;
            /* #endregion */

            /* #region New D0 K resonances */
            case 21:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 22:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 23:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 24:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                reson->getMassPar()->addGaussianConstraint(3.92615, 0.00228685);
                reson->getWidthPar()->addGaussianConstraint(0.0337151, 0.00637956);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            /* #endregion */

            /* #region New anti-D0 K resonances */
            case 25:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 26:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 27:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            case 28:
                reson->getWidthPar()->valueAndRange(0.025, 0.020, 0.500);
                // BW radius
                reson->changeBWBarrierRadii(_bwRadius_res_charm, _bwRadius_parent);
                break;
            /* #endregion */

            /* #region Non-resonant candidates */
            case 29:
                break;
            case 30:
                reson->floatResonanceParameter("alpha");
                break;
            case 31:
                reson->floatResonanceParameter("alpha");
                break;
            case 32:
                reson->floatResonanceParameter("alpha");
                break;
            case 33:
                reson->setResonanceParameter("alpha", 0.68);
                //reson->floatResonanceParameter("alpha");
                break;
            case 34:
                break;
                /* #endregion */
        }
    }
    //std::cout << "INFO in addResonance (CUSTOM) : HERE 2" << std::endl;
    /*
    std::vector<LauParameter*> testVec = resParams->getParameters();
    for (auto param : testVec){
        std::cout << "Param " << param->name() << " value " << param->value() << std::endl;
    }
    */
    return resParams;
}

std::vector<LauAbsCoeffSet*>  addUncorrelatedResonances(LauIsobarDynamics* sigModel, std::vector<int> resonanceList, bool fixMass, bool fixWidth) {
    // Rewrite of function to build resonance model from list of resonance indices
    std::vector<LauAbsCoeffSet*> coeffset;
    LauAbsResonance* reson(0);

    for (auto resonanceKey : resonanceList) {
        resonInfo resInfo = getDefaultResInfo(resonanceKey);
        if (resInfo.resName == "DefaultName"){ // If resonance is not defined in getResInfo then name should be default
            std::cout << "ERROR in buildResonanceModel : Resonance ID " << resonanceKey << " is undefined." << std::endl;
            exit(EXIT_FAILURE);
        } else {
            // Adding resonance using information from resInfo
            LauAbsCoeffSet* resParams = addResonance(sigModel, resInfo, fixMass, fixWidth);
            coeffset.push_back(resParams);
        }
    }
    return coeffset;
}

std::vector<LauAbsCoeffSet*>  addUncorrelatedResonances(LauIsobarDynamics* sigModel, std::vector<resonInfo> resonanceList, bool fixMass, bool fixWidth) {
    // Overloaded addUncorrelatedResonances function to add resonances to a model with custom amplitudes and phases specified by resonInfo structs
    std::vector<LauAbsCoeffSet*> coeffset;
    LauAbsResonance* reson(0);

    for (auto resInfo : resonanceList) {
        if (resInfo.resName == "DefaultName"){ // If resonance is not defined in getResInfo then name should be default
            std::cout << "ERROR in buildResonanceModel : Resonance ID " << resInfo.resID << " is undefined." << std::endl;
            exit(EXIT_FAILURE);
        } else {
            // Adding resonance using information from resInfo
            LauAbsCoeffSet* resParams = addResonance(sigModel, resInfo, fixMass, fixWidth);

            // Setting second stage fit
            for (auto subParam : resParams->getParameters()){
                subParam->secondStage(resInfo.secondStage);
            }

            coeffset.push_back(resParams);
        }
    }
    return coeffset;
}

resonInfo getCorrelatedInfo(resonInfo resInfo){
    // Returns resInfo struct with modified amplitudes to account for quantum correlations in the DDbar system
    resonInfo correlatedResInfo = resInfo;
    correlatedResInfo.resAmp = resInfo.resAmp*getAmpFactor(resInfo.resID);
    return correlatedResInfo;
}

LauSimpleFitModel* buildIsobarModel(std::vector<resonInfo> resInfoVec){
    // Sets up a fit model wit the correct amplitudes and phases given a vector of resonInfo structs
    Bool_t squareDP = kFALSE;

    LauDaughters *daughters = new LauDaughters("B+", "D0_bar", "D0", "K+", squareDP);

    LauVetoes *vetoes = new LauVetoes();
    LauEffModel *effModel = new LauEffModel(daughters, vetoes);  // Efficiency model


    // Defining isobar decay model
    LauIsobarDynamics *sigModel = new LauIsobarDynamics(daughters, effModel);
    std::vector<LauAbsCoeffSet*> coeffset;

    // Adding resonances to model
    for (auto resInfo : resInfoVec) {
        LauAbsCoeffSet* resParams = addResonance(sigModel, resInfo, kTRUE, kTRUE);
        coeffset.push_back(resParams);
    }

    sigModel->setASqMaxValue(9.0);

    // Setting model amplitudes and phases
    LauSimpleFitModel* fitModel = new LauSimpleFitModel(sigModel);
    for (std::vector<LauAbsCoeffSet *>::iterator iter = coeffset.begin(); iter != coeffset.end(); ++iter) {
        fitModel->setAmpCoeffSet(*iter);
    }

    return fitModel;
}

std::vector<resonInfo> changeNormalisation(std::vector<resonInfo> resModel, int newNormInd, int currentNormInd){
    // Function to construct a new vector of resonInfo with new normalisation mode
    std::vector<resonInfo> newNormModel;
    // Amplitude and phase of new normalisation resonance in old normalisation
    Double_t normAmpOld;
    Double_t normPhaseOld;

    // Extracting normAmpOld and normPhaseOld
    for (auto res : resModel){
        if (res.resID == newNormInd){
            normAmpOld = res.resAmp;
            normPhaseOld = res.resPhase;
        }
    }

    // Constructing list of resonInfo with amplitudes and phases normalised to new mode
    for (auto res: resModel){
        resonInfo resNewNorm = res;
        resNewNorm.resAmp = res.resAmp/normAmpOld;
        resNewNorm.resPhase = normPhaseOld - res.resPhase;

        newNormModel.push_back(resNewNorm);
    }

    return newNormModel;
}