#include <iostream>
#include <cmath>
#include <fstream>

#include "buildResonanceModel.h"
#include "modelUtilities.h"
#include "TROOT.h"
#include "TStyle.h"
#include "TFile.h"
#include "TTree.h"
#include "TCanvas.h"
#include "TLatex.h"
#include "TH2F.h"
#include "TKDTreeBinning.h"
#include "TH2Poly.h"
#include "TTreeReader.h"
#include "ROOT/RDataFrame.hxx"

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << " [fitResultsPath] [savePath] [nevts] [fitExptNum=0] [nToysGen=1] [correlated=0] [resIndFile = '']\n"
        << std::endl;
}


int main(int argc, char** argv){
    std::cout << argc << '\n';
    if (argc < 7) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }

    TString fitResultsPath = argv[1]; // Path to fit results
    TString genSavePath = argv[2]; // Save path for toy
    int nevts = atoi(argv[3]); // Num. events per toy
    int exptNum = atoi(argv[4]); // Which experiment to read from fit (if fit results file contains multiple fits)
    int nToysGen = atoi(argv[5]); // Number of toys to generate
    bool correlated;
    if (atoi(argv[6]) == 1){
        correlated = true;
    } else{
        correlated = false;
    }
    std::string resIndFile = argv[7];

    // Reading in resonance index list
    std::vector<int> resonIndexList; 
    if (resIndFile == ""){
        std::cout << "INFO in genFromFit.cpp : No resonance file specified, using full resonance model" << '\n';
        resonIndexList = fullResonanceList;
    } else {
        std::string fileLine;
        std::ifstream resModelFile;
        resModelFile.open(resIndFile);
        while (getline(resModelFile, fileLine)){
            resonIndexList.push_back(std::stoi(fileLine));
        }
        resModelFile.close();
    }

    // Reading in fit results
    std::vector<resonInfo> fittedModel = readFitResults(fitResultsPath, resonIndexList, exptNum);
    std::vector<resonInfo> genModel;
    if (correlated) {
        for (auto resInfo : fittedModel) {
            genModel.push_back(getCorrelatedInfo(resInfo));
        }
    } else {
        genModel = fittedModel;
    }
    genToyHist(genModel, nevts, genSavePath, nToysGen);
    return 0;
}