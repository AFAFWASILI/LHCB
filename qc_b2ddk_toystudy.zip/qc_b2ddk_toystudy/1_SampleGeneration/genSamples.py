from funcs import *
import os
import subprocess

#funcs.plotUnbinnedm12Sq("/home/okuu/cernbox/PGR/Software/Laura/Laura_master_build/B2DDK/Output/gen-B2D0D0bK.root", "test.png")

# Configuration
genFileExecutables = ["genUncorrelatedSample", "genCorrelatedSample"] # Names of the compiled executable files used to generate the decay samples
genSaveDir = ["output/Gen/UC", "output/Gen/QC"] # Save directories for each sample
genSavePrefix = ["B2D0D0bK", "B2D0D0bK-Correlated"] # Save prefix for histograms and .tex tables of the generated samples
genDataSaveName = ["gen-B2D0D0bK.root", "gen-B2D0D0bK-Correlated.root"] # File names of the generated samples
figSaveName = ["dalitz_m12Sqm23Sq.png", "dalitz_m12Sqm23Sq_correlated.png"]
genNevents = [1000, 1000]

for i in range(len(genFileExecutables)):
    # Constructing file paths
    genExecutablePath = os.path.join("bin", genFileExecutables[i])
    genSampleSavePath = os.path.join(genSaveDir[i], genDataSaveName[i])
    genFigureSavePath = os.path.join(genSaveDir[i], figSaveName[i])
    genSampleSavePrefix = os.path.join(genSaveDir[i], genSavePrefix[i])
    print(genSampleSavePrefix)
    
    # Running generator
    genCommand = f"{genExecutablePath} gen {genNevents[i]} {genSampleSavePath} {genSampleSavePrefix}"
    os.system(genCommand)
    
    plotUnbinnedm12Sq(genSampleSavePath, os.path.join(genSaveDir[i], f"{genSavePrefix[i]}-m12Sqm23Sq.png"))
    plot1DHist(genSampleSavePath, "m12Sq", r'$\\m^{2}(D^{0}\bar{D}^{0})\quad(GeV^{2})$', os.path.join(genSaveDir[i], f"{genSavePrefix[i]}-m12Sq.png"))
    plot1DHist(genSampleSavePath, "m23Sq", r'$\\m^{2}(\bar{D}^{0}K^{+})\quad(GeV^{2})$', os.path.join(genSaveDir[i], f"{genSavePrefix[i]}-m23Sq.png"))