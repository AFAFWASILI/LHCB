import uproot
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import mplhep

plt.rcParams["text.usetex"] = True

def plotUnbinnedm12Sq(dataPath, savepath):
    with uproot.open(dataPath+":DecayTree") as decayTree:
        m12Sq = decayTree["m12Sq"]
        m23Sq = decayTree["m23Sq"]
        plt.style.use(mplhep.style.LHCb2)
        fig, ax = plt.subplots(figsize=(16, 12))
        plt.scatter(m12Sq, m23Sq, c='black', s=4)
        plt.xlabel(r'$\\m^{2}(D^{0}\bar{D}^{0})\quad(GeV^{2})$')
        plt.ylabel(r'$\\m^{2}(\bar{D}^{0}K^{+})\quad(GeV^{2})$')
        plt.savefig(savepath)
        
def plot1DHist(dataPath, varname, varlabel, savepath):
    with uproot.open(dataPath+":DecayTree") as decayTree:
        varArray = decayTree[varname].array()
        plt.style.use(mplhep.style.LHCb2)
        fig, ax = plt.subplots(figsize=(16, 12))
        h, bins = np.histogram(varArray, 40)
        mplhep.histplot(h, bins, yerr=np.sqrt(h), ax = ax)
        plt.xlabel(varlabel)
        plt.savefig(savepath)