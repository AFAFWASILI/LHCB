#include <cstdlib>
#include <iostream>
#include <vector>

#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TTree.h"

#include "buildResonanceModel.h"
#include "modelUtilities.h"
#include "resonInfo.h"

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << " [nEvts] [genRootFilePath] [genOutputPathPrefix] [correlated = 0 or 1] [ntoys=1]" << std::endl;
}

int main(int argc, char **argv) {
    std::cout << argc << std::endl;
    /* #region CLI Argument handling*/
    if ((argc != 6) && (argc != 5)) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }

    Bool_t isToy(kTRUE);

    // Configuring file names
    TString fitSamplePath;
    TString fitOutputPathPrefix;  // If file path prefix is "XXX/YYY/ZZZ/gen-", then file will be saved as "XXX/YYY/ZZZ/gen-fitHist.root" (fitHist defined in CLI handling section)
    TString genOutputPathPrefix;
    TString genDataSavePath;
    TString histFilePath;
    TString tableFilePath;
    TString dataFile("");  // Output containing generated events if running in "gen" mode, input w/data in "fit" mode
    TString treeName("DecayTree");
    Int_t ntoys;
    double nEventsData;
    bool correlated;

    // Parsing arguments
    nEventsData = atoi(argv[1]);  // Set number of generated events
    genDataSavePath = argv[2];
    genOutputPathPrefix = argv[3];
    correlated = atoi(argv[4]); // Whether to generate a correlated sample or not
    if (argc == 5){
        ntoys = 1;
    } else {
        ntoys = atoi(argv[5]);
    }
    // Setting I/O paths
    dataFile = genDataSavePath;
    histFilePath = genOutputPathPrefix + "dummy.root";
    tableFilePath = genOutputPathPrefix + "-genResults.tex";

    std::vector<resonInfo> resInfoVec;
    for (auto resID : fullResonanceList){
        resonInfo resInfo = getDefaultResInfo((resID));
        if (correlated) {
            resInfo = getCorrelatedInfo(resInfo);
        }
        resInfoVec.push_back(resInfo);
    }


    LauSimpleFitModel* fitModel = buildIsobarModel(resInfoVec);
    LauParameter *nSigEvents = new LauParameter("signalEvents", nEventsData, -1000.0, nEventsData, kTRUE);

    // Configuring the fit
    fitModel->setNSigEvents(nSigEvents);
    // fitModel->setNExpts( 1, 0 , kFALSE); // (kTRUE if you want generation within gaussian mean, see inc/LauFitObject.hh)
    // fitModel->setNExpts( nExpt, firstExpt, isToy );
    fitModel->setNExpts(ntoys, 0, kFALSE);
    fitModel->useAsymmFitErrors(kFALSE);
    fitModel->useRandomInitFitPars(kTRUE);
    fitModel->doPoissonSmearing(kFALSE);
    fitModel->doEMLFit(false);

    // Executing generation/fit
    fitModel->run("gen", dataFile, treeName, histFilePath, tableFilePath);

    return EXIT_SUCCESS;
}