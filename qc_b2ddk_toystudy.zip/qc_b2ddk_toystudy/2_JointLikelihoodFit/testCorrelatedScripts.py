"""
Script for testing adaptations of scripts/tasks for analysing results of simultaneous fits
"""
import os

if __name__ == "__main__":
    simFitResults = "output/JointFit/UC/UC-fitHist-9.root"
    fitSampleUC = "output/Gen/UC/gen-UC.root"
    fitSampleQC = "output/Gen/QC/gen-QC.root"
    fitSavePrefix = "output/temp/simfit-test-"
    os.system(f"./bin/plotDPProjection {simFitResults} {fitSampleUC} {fitSavePrefix} 1 {fitSampleQC}")