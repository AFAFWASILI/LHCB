/*
Code for setting up fit coordinator to perform a simultaneous fit of
flavour and double-CP tagged samples of B+/- -> D0 D0bar K+/-
decays for toy study on the effects of QC D0D0bar systems in amplitude analyses
*/
#include <iostream>

#include "LauSimFitCoordinator.hh"
#include "TFile.h"
#include "TTree.h"
#include "TROOT.h"

void usage(std::ostream& out, const TString& progName) {
    out << "Usage:\n";
    out << progName << " [outputPath] [ntoys] [port = 0]\n";  // Need to change at some point
}

int main(int argc, char** argv) {

    ROOT::EnableThreadSafety();

    UInt_t nTasks = 2;  // Number of task processes the coordinator expects connection from (i.e. number of samples to be fitted simultaneously if we have each task for fitting each sample)
    UInt_t nExpts = atoi(argv[2]);  // Number of toy experiments - Might want to fiddle with this later to perform repeated fits
    UInt_t firstExpt = 0; // Indexing/labelling experiments - should be fine to leave at 0

    UInt_t port = atoi(argv[3]); // Network port for fit coordinator to listen on

	Bool_t useAsymmErrors = kFALSE;
	Bool_t twoStageFit = kFALSE;

    TString ntupleName = argv[1]; // Name of file containing fit results

    LauSimFitCoordinator coordinator( nTasks, port ); // Initialise fit coordinator
    coordinator.setNExpts( nExpts, 0, kTRUE );
    coordinator.runSimFit( ntupleName, useAsymmErrors, twoStageFit );

    // To-do : Try to put all the resonance definitions into a single function
    return EXIT_SUCCESS;
}