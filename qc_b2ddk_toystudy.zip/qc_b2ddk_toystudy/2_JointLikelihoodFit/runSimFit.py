import os
import sys
import subprocess
import time
import argparse
import uproot
from glob import glob

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Runs a simultaneous fit on a correlated and uncorrelated sample')
    parser.add_argument('samplePathUC', action='store', metavar='samplePathUC', type=str, help='Path to directory containing uncorrelated samples')
    parser.add_argument('samplePathQC', action='store', metavar='samplePathQC', type=str, help='Path to directory containing correlated samples')
    parser.add_argument('outdirJointFit', action='store', type=str, help='Path to directory containing joint fit results')
    parser.add_argument('saveTag', action='store', type=str, help='Save tag for files produced from fit')
    parser.add_argument('--nfits', action='store', type=int, help='Number of repeated fits to perform', default=20, required=False)
    args = vars(parser.parse_args())
    
    sampleUCPath = args['samplePathUC']
    sampleQCPath = args['samplePathQC']
    outdirJointFit = args['outdirJointFit']
    saveTag = args['saveTag']
    nfits = args['nfits']
    genNewSamples = True
    """
    genOutdirUncorrelated = "output/Gen/UC"
    genOutdirCorrelated = "output/Gen/QC"
    outdirJointFit = "output/JointFit"
    nevtsUC = 5000
    nevtsQC = 5000
    nFits = 50
    genNewSamples = False
    """
    
    
    # Checking if QC and UC samples exists. If not, exit script
    if not(os.path.exists(sampleUCPath)):
        sys.exit(f"INFO in runSimFit.py : Uncorrelated sample at {sampleUCPath} does not exist; terminating.")
    
    if not(os.path.exists(sampleQCPath)):
        sys.exit(f"INFO in runSimFit.py : Correlated sample at {sampleQCPath} does not exist; terminating.")
    
    # To-do: Check if output directory exists and create if they dont 
    
    # Performing simultaneous fit
    for i in range(nfits):
        print(f"Running fit {i}")
        
        coordinatorLogPath = f"{outdirJointFit}/Coordinator/Logs/{saveTag}-fit{i}.log"
        coordinatorOutputPath = f"{outdirJointFit}/Coordinator/Tuples/{saveTag}-fit{i}-coordinator.root"
        taskUCLogPath = f"{outdirJointFit}/UC/Logs/{saveTag}-fit{i}.log"
        taskQCLogPath = f"{outdirJointFit}/QC/Logs/{saveTag}-fit{i}.log"
        tupleUCSaveTag = f"{outdirJointFit}/UC/Tuples/{saveTag}-fit{i}-"
        tupleQCSaveTag = f"{outdirJointFit}/QC/Tuples/{saveTag}-fit{i}-"
        
        # Starting fit coordinator
        coordinatorProcess = subprocess.Popen(f"./bin/jointFitCoordinator {coordinatorOutputPath} 1 0 > {coordinatorLogPath} 2>&1 & sleep 5", shell=True)
        time.sleep(1)
        # Wait until coordinator is initialised and waiting for connections
        nLinesCoordinator = sum(1 for _ in open(coordinatorLogPath))
        while nLinesCoordinator < 2:
            time.sleep(5)
            nLinesCoordinator = sum(1 for _ in open(coordinatorLogPath))
        port = 0
        
        with open(coordinatorLogPath) as coordinatorLog:
            for line in coordinatorLog:
                if "INFO in LauSimFitCoordinator::initSockets : Waiting for connection" in line:
                    port = line.split()[-1]
            
        # Starting joint fit tasks
        subprocess.run(f"./bin/jointFitTask {sampleUCPath} {tupleUCSaveTag} localhost {port} 1 0 > {taskUCLogPath} 2>&1 & sleep 1", shell=True)
        subprocess.run(f"./bin/jointFitTask {sampleQCPath} {tupleQCSaveTag} localhost {port} 1 1 > {taskQCLogPath} 2>&1 & sleep 1", shell=True)
        coordinatorProcess.wait()
    
    # Determining best fit
    fitResultsUCList = glob(f"{outdirJointFit}/UC/*fitHist.root")
    fitLikelihoodDict = {}
    for file in fitResultsUCList:
        with uproot.open(file + ":fitResults") as resultTree:
            fitLikelihoodDict[file] = resultTree["NLL"].array()[0]