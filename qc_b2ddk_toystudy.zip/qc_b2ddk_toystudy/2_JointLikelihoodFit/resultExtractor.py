"""
Aggregates results from multiple fits and saves as a csv file
"""
import uproot
import glob as glob
import awkward as ak
import numpy as np
import sys

if __name__ == '__main__':
    fitResultDir = "output/JointFit/Results"
    fitResultsOutput = "output/JointFit/Results/fitResults.csv"
    fitFiles = glob.glob(fitResultDir+"/*.root")
    
    readColName = False
    colNames = np.array([])
    lines = []

    if (len(fitFiles) == 0):
        print("No fit results found, stopping")
        sys.exit()
    else:
        for file in uproot.iterate(fitFiles):
            if (not readColName): # Reads in column names
                readColName = True
                colNames = file.fields
                colNames = ','.join(colNames)
            
            vals = list(ak.to_numpy(file)[0])
            lines.append(vals)
    
        print(f"Fit results saved to {fitResultsOutput}")
        np.savetxt(fitResultsOutput, lines, header=colNames, delimiter=',', comments='')
                