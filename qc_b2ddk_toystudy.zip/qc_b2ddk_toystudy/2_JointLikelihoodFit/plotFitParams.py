import numpy as np
import matplotlib.pyplot as plt
import mplhep
import re

def plot1DHist(arr, label, truthval, savepath):
    mplhep.styles.use("LHCb2")
    fig, ax = plt.subplots()
    plt.hist(arr, bins=20)
    plt.xlabel(f"Fit value - {label}")
    plt.axvline(truthval, color='r', label=f'Truth val. = {round(truthval,2)}', zorder=4)
    plt.legend()
    plt.savefig(savepath)
    

if __name__ == "__main__":
    fitResultsPath = "output/JointFit/Results/fitResults.csv"
    plotSaveDir = "output/JointFit/Results/Plots/"
    fitResults = np.genfromtxt(fitResultsPath, dtype=float, delimiter=',', names=True)
    colNames = fitResults.dtype.names
    
    # Defining what parameters to plot - Currently only plotting the fitted amplitudes and phases
    ampParamNames = [x for x in colNames if re.fullmatch("A[1-8]_A", x)]
    ampParamNames += [x for x in colNames if re.fullmatch("A[1-8]_Delta", x)]
    
    for param in ampParamNames:
        plotSavePath = plotSaveDir + f"/hist-{param}.png"
        plot1DHist(fitResults[param], param, fitResults[param+"_True"][0], plotSavePath)