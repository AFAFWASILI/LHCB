#include <cstdlib>
#include <iostream>
#include <vector>
#include <cstring>

#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauAbsCoeffSet.hh"
#include "LauFormulaPar.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TTree.h"
#include "TROOT.h"
#include "buildResonanceModel.h"

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << "[fitSamplePath] [fitOutputPathPrefix] [hostname] [port] [ntoys=1] [correlated=0]\n"
        << std::endl;
}

int main(int argc, char **argv) {
    /* #region CLI Argument handling*/
    if (argc < 7) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }


    Bool_t isToy(kTRUE);

    // Configuring file names
    TString fitSamplePath;
    TString fitOutputPathPrefix;  // If file path prefix is "XXX/YYY/ZZZ/gen-", then file will be saved as "XXX/YYY/ZZZ/gen-fitHist.root" (fitHist defined in CLI handling section)
    TString genOutputPathPrefix;
    TString genDataSavePath;
    TString histFilePath;
    TString tableFilePath;
    TString hostname;
    UInt_t port;
    TString dataFile;  // Output containing generated events if running in "gen" mode, input w/data in "fit" mode
    TString treeName = "DecayTree";

    // Parsing arguments
    fitSamplePath = argv[1];
    fitOutputPathPrefix = argv[2];
    hostname = argv[3];
    port = atoi(argv[4]);
    int ntoys = atoi(argv[5]);
    bool correlated = false;
    if (atoi(argv[6]) == 1) {
        correlated = true;
    }



    // Setting I/O paths
    dataFile = fitSamplePath;
    histFilePath = fitOutputPathPrefix + "fitHist.root";
    tableFilePath = fitOutputPathPrefix + "fitResults.tex";

    // Setting nEventsData to number of events in tree
    TFile *inputFile = new TFile(dataFile);  // Currently set up to
    TTree *inputTree = (TTree *)inputFile->Get(treeName);
    UInt_t nEventsData = inputTree->GetEntries();

    /* #endregion*/

    Bool_t squareDP = kFALSE;  // PN: I don't think we need squareDP for this toy study, well at least not the first stage.....
    Bool_t fixMass = kTRUE;    // Fix mass of resonances in fit
    Bool_t fixWidth = kTRUE;   // Fix width of resonances in fit

    /* #region Defining decay model */
    /*
    The indices of the resonances correspond to:

    1 - psi(3770)
    2 - chi_c2(2P)
    3 - psi(4040)
    4 - psi(4160)
    5 - psi(4415)
    38 - chi_c0(2P)
    6 - Ds*+_0(2317)
    7 - Ds*+_2(2573)
    8 - Ds*+_1(2700)
    */

    LauDaughters *daughters = new LauDaughters("B+", "D0_bar", "D0", "K+", squareDP);

    LauVetoes *vetoes = new LauVetoes();
    LauEffModel *effModel = new LauEffModel(daughters, vetoes);  // Efficiency model

    // Defining isobar decay model
    LauIsobarDynamics *sigModel = new LauIsobarDynamics(daughters, effModel);
    sigModel->setNarrowResonanceThreshold(0.03);
    std::vector<LauAbsCoeffSet*> uncorrelatedCoeffset = addUncorrelatedResonances(sigModel, fitResonanceList, fixMass, fixWidth); // Adding resonances to isobar model
    std::vector<LauAbsCoeffSet*> coeffset;

    if (correlated) {
        std::vector<double> ampFactors = computeAmpFactors(fitResonanceList);
        for (int i = 0; i < uncorrelatedCoeffset.size(); i++) {
            //LauAbsCoeffSet* newAmp = uncorrelatedCoeffset[i]->createClone(uncorrelatedCoeffset[i]->name(), LauAbsCoeffSet::TieMagnitude, ampFactors[i]);
            coeffset.push_back(uncorrelatedCoeffset[i]->createClone(uncorrelatedCoeffset[i]->name(), LauAbsCoeffSet::TieMagnitude, ampFactors[i]));
        }
    } else {
        coeffset = uncorrelatedCoeffset;
    }

    sigModel->setASqMaxValue(9.0);
    LauSimpleFitModel *fitModel = new LauSimpleFitModel(sigModel);

    for (std::vector<LauAbsCoeffSet*>::iterator iter=coeffset.begin(); iter!=coeffset.end(); ++iter){
        LauAbsCoeffSet* resParams;
        resParams = *iter;
        fitModel->setAmpCoeffSet(*iter);
    }


    // Some arcane pointer magic to match parameters between the two tasks which I don't understand.
    if ( correlated ) {
        for ( std::size_t i{0}; i < coeffset.size(); ++i ) {
            uncorrelatedCoeffset[i]->index( coeffset[i]->index() );
        }
    }

    
    // LauParameter* nSigEvents = new LauParameter("signalEvents",nEventsData,-1000.0,100000.0,kTRUE);
    LauParameter *nSigEvents = new LauParameter("signalEvents", nEventsData, -1000.0, nEventsData, kTRUE);

    // Configuring the fit
    fitModel->setNSigEvents(nSigEvents);
    // fitModel->setNExpts( 1, 0 , kFALSE); // (kTRUE if you want generation within gaussian mean, see inc/LauFitObject.hh)
    // fitModel->setNExpts( nExpt, firstExpt, isToy );
    fitModel->setNExpts(ntoys, 0, kFALSE);
    fitModel->useAsymmFitErrors(kFALSE);
    fitModel->useRandomInitFitPars(kTRUE);
    fitModel->doPoissonSmearing(kTRUE);
    fitModel->doEMLFit(false);

    // Executing generation/fit
    fitModel->runTask(dataFile, treeName, histFilePath, tableFilePath, hostname, port);

    return EXIT_SUCCESS;
}
