"""
Plots the correlation matrix between the fit parameters
"""
import uproot
import glob as glob
import awkward as ak
import numpy as np
import sys
import re
import matplotlib.pyplot as plt
import mplhep

if __name__ == '__main__':
    fitResultDir = "output/FittingTests/SimFit/UC/Tuples/UC1000evts-QC1000evts-fit*"
    matrixSaveDir = "output/temp"
    fitFiles = glob.glob(fitResultDir)

    readColName = False
    colNames = []
    ampParamNames = []
    nparams = 0

    if (len(fitFiles) == 0):
        print("No fit results found, stopping")
        sys.exit()
    else:

        for i in range(len(fitFiles)):
            print(fitFiles[i])

            with uproot.open(fitFiles[i]+":fitResults") as file:
                # Getting fit number
                fitNum = int(re.findall('\d+', fitFiles[i])[0])

                if (not readColName): # Reads in column names and extracts indices corresponding to the 
                    readColName = True
                    colNames = file.keys()
                    ampParamNames = [x for x in colNames if re.fullmatch("A[1-8]_A", x)]
                    ampParamNames += [x for x in colNames if re.fullmatch("A[1-8]_Delta", x)]
                    nparams = len(ampParamNames)

                    corrMatrix = []
                    
                    # Reading correlation matrix
                    for i in range(nparams):
                        param_i = ampParamNames[i]
                        corrMatrixRow = []
                        for j in range(nparams):
                            if i == j: # Correlation with self
                                corrMatrixRow.append(1)
                            elif j > i: # Disabling upper half of matrix due to symmetry to make it easier to read
                                corrMatrixRow.append(np.nan)
                            else:
                                param_j = ampParamNames[j]
                                corrParamName = f"corr__{param_i}__{param_j}"
                                corrMatrixRow.append(round(file[corrParamName].array(library='np')[0], 3))
                        corrMatrix.append(corrMatrixRow)
                    
                    # Plotting correlation matrix
                    #mplhep.styles.use("LHCb2")
                    fig, ax = plt.subplots()
                    fig.set_figheight(10)
                    fig.set_figwidth(10)
                    im = ax.imshow(np.abs(corrMatrix), vmin=0, vmax=1, cmap="OrRd")
                    
                    plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")
                    
                    for i in range(nparams):
                        for j in range(nparams):
                            if j <= i:
                                text = ax.text(j, i, corrMatrix[i][j], ha="center", va="center")

                    ax.set_xticks(np.arange(len(ampParamNames)), labels=ampParamNames)
                    ax.set_yticks(np.arange(len(ampParamNames)), labels=ampParamNames)
                    

                    fig.tight_layout()
                    savePath = matrixSaveDir + f"/corrMatrix-{fitNum}.png"
                    plt.savefig(savePath)

        print(f"Correlation matrices saved to {matrixSaveDir}")