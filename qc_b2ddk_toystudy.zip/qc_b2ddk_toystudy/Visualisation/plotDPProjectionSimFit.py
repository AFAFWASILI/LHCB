import sys
import os
from argparse import ArgumentParser
from warnings import simplefilter
import pandas as pd
import numpy as np
import uproot
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import mplhep

sys.path.insert(0, './Visualisation')
from plotDPProjection import *

if __name__ == "__main__":
    parser = ArgumentParser(description="Makes DP projection plots")
    parser.add_argument('fitResultPath', action='store', type=str, help='Path to fit results (Uncorrelated)')
    parser.add_argument('samplePathUC', action='store', type=str, help='Path to flavour-tagged toy on which the fit is performed')
    parser.add_argument('samplePathQC', action='store', type=str, help='Path to flavour-tagged toy on which the fit is performed')
    parser.add_argument('fitSavePrefix', action='store', type=str, help='Save path and label for plots')
    #parser.add_argument('--fitSamplePathQC', help='Path to QC sample used in fit if flagged as simultaneous fit', default="", required=False)
    args = vars(parser.parse_args())

    fitResultPath = args['fitResultPath']
    fitSamplePathUC = args['samplePathUC']
    fitSamplePathQC = args['samplePathQC']
    fitSavePrefix = args['fitSavePrefix']
    #fitSamplePathQC = args['fitSamplePathQC']
    
    simplefilter(action="ignore", category=pd.errors.PerformanceWarning)
    
    os.system(f"./bin/plotDPProjection {fitResultPath} {fitSamplePathUC} {fitSavePrefix} 1 {fitSamplePathQC}")
    
    fitComponentObjs = []
    fitComponentObjsQC = []
    
    fullFitInfo = resToyInfo('fullFit')
    fullFitInfo.fitFrac = 1
    fitComponentObjs.append(fullFitInfo)
    
    fullFitInfoQC = resToyInfo('fullFitQC')
    fullFitInfoQC.fitFrac = 1
    fitComponentObjsQC.append(fullFitInfoQC)
    
    fitFracs = {}
    fitFracsQC = {}
    
    # Parsing for fit fractions
    for i in range(len(fitComponents)):
        fitFracFile = open("output/temp/fitFracsFile.txt", mode='r')
        lines = fitFracFile.readlines()
        for line in lines:
            targetLine = f"INFO in LauIsobarDynamics::initialise : Initial fit fraction for amplitude ({i},{i})"
            if targetLine in line:
                fitFrac = float(line.split(' ')[-1])
                fitFracs[fitComponents[i]] = fitFrac
        
        fitFracFileQC = open("output/temp/fitFracsFileQC.txt", mode='r')
        linesQC = fitFracFileQC.readlines()

        for line in linesQC:
            targetLine = f"INFO in LauIsobarDynamics::initialise : Initial fit fraction for amplitude ({i},{i})"
            if targetLine in line:
                fitFrac = float(line.split(' ')[-1])
                fitFracsQC[fitComponents[i]] = fitFrac
    
    # Aggregating component information:
    for comp in fitComponents:
        compInfo = resToyInfo(comp)
        compInfo.fitFrac = fitFracs[comp]
        fitComponentObjs.append(compInfo)

        compInfoQC = resToyInfo(comp)
        compInfoQC.fitFrac = fitFracsQC[comp]
        fitComponentObjsQC.append(compInfoQC)
    
    # Reading in data
    dataArr = uproot.open(fitSamplePathUC + ":DecayTree").arrays(["m12", "m13", "m23", "m12Sq", "m13Sq", "m23Sq"], library='pd')
    dataArrQC = uproot.open(fitSamplePathQC + ":DecayTree").arrays(["m12", "m13", "m23", "m12Sq", "m13Sq", "m23Sq"], library='pd')

    plotProjectionPlot(dataArr, fitComponentObjs, "m12", f"{fitSavePrefix}-UC-m12-projection.pdf")
    plotProjectionPlot(dataArr, fitComponentObjs, "m13", f"{fitSavePrefix}-UC-m13-projection.pdf")
    plotProjectionPlot(dataArr, fitComponentObjs, "m23", f"{fitSavePrefix}-UC-m23-projection.pdf")

    plotProjectionPlot(dataArrQC, fitComponentObjsQC, "m12", f"{fitSavePrefix}-QC-m12-projection.pdf")
    plotProjectionPlot(dataArrQC, fitComponentObjsQC, "m13", f"{fitSavePrefix}-QC-m13-projection.pdf")
    plotProjectionPlot(dataArrQC, fitComponentObjsQC, "m23", f"{fitSavePrefix}-QC-m23-projection.pdf")