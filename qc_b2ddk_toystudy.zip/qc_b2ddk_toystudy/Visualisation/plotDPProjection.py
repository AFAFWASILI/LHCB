import os
from argparse import ArgumentParser
from warnings import simplefilter
import pandas as pd
import numpy as np
import uproot
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import mplhep


# WARNING : Joint fit currently not supported
resToyPaths = {
    "fullFit" : "output/temp/total_fit.root",
    "fullFitQC" : "output/temp/total_fit_QC.root",
    "chi_c0_2P" : "output/temp/chi_c0(2P)_fit.root",
    "chi_c2_2P" : "output/temp/chi_c2(2P)_fit.root",
    "Ds1_2700" : "output/temp/Ds*+_1(2700_fit.root",
    "Ds2_2573" : "output/temp/Ds*+_2(2573_fit.root",
    "psi_3770" : "output/temp/psi(3770)_fit.root",
    "psi_4040" : "output/temp/psi(4040)_fit.root",
    "psi_4160" : "output/temp/psi(4160)_fit.root",
    "psi_4415" : "output/temp/psi(4415)_fit.root",
    "BelleNR+" : "output/temp/BelleNR+_fit.root"
}

dpLatexLabels = {
    "m12" : r"$m(D^{0}\bar{D}^{0})\quad (\text{GeV}/c^{2})$",
    "m13" : r"$m(\bar{D}^{0}K^{+})\quad (\text{GeV}/c^{2})$",
    "m23" : r"$m(D^{0}K^{+})\quad (\text{GeV}/c^{2})$",
    "m12Sq" : r"$m^{2}(D^{0}\bar{D}^{0})\quad (\text{GeV}/c^{2})^{2}$",
    "m13Sq" : r"$m^{2}(\bar{D}^{0}K^{+})\quad (\text{GeV}/c^{2})^{2}$",
    "m23Sq" : r"$m^{2}(D^{0}K^{+})\quad (\text{GeV}/c^{2})^{2}$",
}

resToyLatex = {
    "fullFit" : r'Full Fit',
    "fullFitQC" : r'Full Fit',
    "chi_c0_2P" : r'$\chi_{c0}(2P)$',
    "chi_c2_2P" : r'$\chi_{c2}(2P)$',
    "Ds1_2700" : r'$D_{s1}^{*+}(2700)$',
    "Ds2_2573" : r'$D_{s2}^{*+}(2573)$',
    "psi_3770" : r'$\psi(3770)$',
    "psi_4040" : r'$\psi(4040)$',
    "psi_4160" : r'$\psi(4160)$',
    "psi_4415" : r'$\psi(4415)$',
    "BelleNR+" : r'Exponential NR'
}

dpBounds = {
    "m12" : [1.86484*2, 5.27934 - 0.493677],
    "m13" : [1.86484 + 0.493677, 5.27934 - 1.86484],
    "m23" : [1.86484 + 0.493677, 5.27934 - 1.86484],
}

resIndDict = {
    "1" : "psi_3770",
    "2" : "chi_c2_2P",
    "3" : "psi_4040",
    "4" : "psi_4160",
    "5" : "psi_4415",
    "38" : "chi_c0_2P",
    "7" : "Ds2_2573",
    "8" : "Ds1_2700",
    "33" : "BelleNR+"
}

dpBounds["m12Sq"] = list(np.array(dpBounds["m12"])**2)
dpBounds["m13Sq"] = list(np.array(dpBounds["m13"])**2)
dpBounds["m23Sq"] = list(np.array(dpBounds["m23"])**2)

class resToyInfo:
    def __init__(self, resName):
        self.resName = resName
        self.toySavePath = resToyPaths[resName]
        self.fitFrac = 0
        
    def printInfo(self):
        print(f"Resonance {self.resName} : Toy at {self.toySavePath} : Fit frac. {self.fitFrac}")

def parseIndVector(filepath, vecName):
    # Reads a vector containing resonance indices from .cpp source file
    cppFile = open(filepath, mode='r')
    lines = cppFile.readlines()
    for line in lines:
        targetLine = f"std::vector<int> {vecName}{{"
        if targetLine in line:
            if line[:2] != '//':
                parsedLine = [i.split('}')[0] for i in line.split('{')[1:]][0]
                parsedLine = parsedLine.replace(' ', '')
                parsedLine = [str(elem) for elem in parsedLine.split(',')]
                return parsedLine

def getHistBinCentre(histBinEdges):
    return [0.5*(histBinEdges[i] + histBinEdges[i+1]) for i in range(len(histBinEdges)-1)]

def plotProjectionPlot(dataArr, fitComponentObjs, dpVar, savePath):
    mplhep.style.use("LHCb2")
    nbins = 50
    binHeights, binEdges = np.histogram(dataArr[dpVar], bins=nbins, range=dpBounds[dpVar])
    binCentres = getHistBinCentre(binEdges)
    binWidth = 0.5*(binEdges[1]-binEdges[0])
    histIntegral = np.sum(binWidth * binHeights)
    plt.scatter(binCentres, binHeights, c='black', s=8, zorder=5)
    plt.errorbar(binCentres, binHeights, yerr=np.sqrt(binHeights), xerr=binWidth, c='black', fmt='none', capsize=0, elinewidth=1, label='Data', zorder=5)
    
    # Components
    c = 2
    for componentObj in fitComponentObjs:
        if componentObj.fitFrac > 0:
            componentArr = uproot.open(f"{componentObj.toySavePath}:DecayTree").arrays([dpVar], library='pd')
            
            compBinHeights, compBinEdges = np.histogram(componentArr, bins = 1000, range = dpBounds[dpVar])
            compBinCentres = getHistBinCentre(compBinEdges)
            compBinWidths = 0.5*(compBinEdges[1] - compBinEdges[0])
            compHistIntegral = np.sum(compBinWidths * compBinHeights)

            weight = componentObj.fitFrac * (histIntegral/compHistIntegral)
            #print(componentObj.fitFrac, componentObj.resName)

            compSpline = make_interp_spline(compBinCentres, weight*compBinHeights)
            xrange = np.linspace(dpBounds[dpVar][0], dpBounds[dpVar][1], 1000)
            yrange = compSpline(xrange)

            plt.plot(xrange, yrange, label=resToyLatex[componentObj.resName], linewidth=2)
            #plt.plot(compBinCentres, compBinHeights*weight, label=resToyLatex[componentObj.resName], linewidth=2)
            plt.legend(fontsize=18)
    
    plt.xlabel(dpLatexLabels[dpVar])
    current_xlims = plt.xlim()
    plt.margins(x = 0.2, y = 0.35)
    plt.gca().set_ylim(bottom=0)
    if "Sq" in dpVar:
        plt.ylabel(r'$\text{Events/} %.3f \ (\text{GeV}/c^{2})^{2}$' % binWidth)
    else:
        plt.ylabel(r'$\text{Events/} %.3f \ \text{GeV}/c^{2}$' % binWidth)
    plt.savefig(savePath)
    plt.close()
    
#fitComponents = ["chi_c2_2P", "chi_c0_2P", "Ds1_2700", "psi_3770", "psi_4040", "psi_4160", "psi_4415", "BelleNR+"] # Need to be in the same order in which the resonances are defined

fitComponents = [resIndDict[resID] for resID in parseIndVector("b2d0d0bk_model/buildResonanceModel.cpp", "fitResonanceList")]


if __name__ == "__main__":
    parser = ArgumentParser(description="Makes DP projection plots")
    parser.add_argument('fitResultPath', action='store', type=str, help='Path to fit results')
    parser.add_argument('fitSamplePath', action='store', type=str, help='Path to data on which the fit is performed')
    parser.add_argument('fitSavePrefix', action='store', type=str, help='Save path and label for plots')
    args = vars(parser.parse_args())

    fitResultPath = args['fitResultPath']
    fitSamplePath = args['fitSamplePath']
    fitSavePrefix = args['fitSavePrefix']
    #fitSamplePathQC = args['fitSamplePathQC']
    
    simplefilter(action="ignore", category=pd.errors.PerformanceWarning)
    
    os.system(f"./bin/plotDPProjection {fitResultPath} {fitSamplePath} {fitSavePrefix} {0}")
    
    fitComponentObjs = []
    fullFitInfo = resToyInfo('fullFit')
    fullFitInfo.fitFrac = 1
    fitComponentObjs.append(fullFitInfo)
    
    fitFracs = {}
    
    # Parsing for fit fractions
    for i in range(len(fitComponents)):
        fitFracFile = open("output/temp/fitFracsFile.txt", mode='r')
        lines = fitFracFile.readlines()
        for line in lines:
            targetLine = f"INFO in LauIsobarDynamics::initialise : Initial fit fraction for amplitude ({i},{i})"
            if targetLine in line:
                fitFrac = float(line.split(' ')[-1])
                fitFracs[fitComponents[i]] = fitFrac
    
    # Aggregating component information:
    for comp in fitComponents:
        compInfo = resToyInfo(comp)
        compInfo.fitFrac = fitFracs[comp]
        fitComponentObjs.append(compInfo)
    
    # Reading in data
    dataArr = uproot.open(fitSamplePath + ":DecayTree").arrays(["m12", "m13", "m23", "m12Sq", "m13Sq", "m23Sq"], library='pd')

    plotProjectionPlot(dataArr, fitComponentObjs, "m12", f"{fitSavePrefix}m12-projection.pdf")
    plotProjectionPlot(dataArr, fitComponentObjs, "m13", f"{fitSavePrefix}m13-projection.pdf")
    plotProjectionPlot(dataArr, fitComponentObjs, "m23", f"{fitSavePrefix}m23-projection.pdf")
        