import sys
import os
from argparse import ArgumentParser
from warnings import simplefilter
import pandas as pd
import numpy as np
import uproot
import matplotlib.pyplot as plt
from scipy.interpolate import make_interp_spline
import mplhep

sys.path.insert(0, './Visualisation')
from plotDPProjection import *


if __name__ == "__main__":
    parser = ArgumentParser(description="Makes DP projection plots of the true amplitude model")
    parser.add_argument('fitSamplePath', action='store', type=str, help='Path to fit sample')
    parser.add_argument('fitSavePrefix', action='store', type=str, help='Save path and label for plots')
    args = vars(parser.parse_args())

    fitSamplePath = args['fitSamplePath']
    fitSavePrefix = args['fitSavePrefix']

    correlated = False
    nevtsToys = 5000000
    fitComponents = [resIndDict[resID] for resID in parseIndVector("b2d0d0bk_model/buildResonanceModel.cpp", "fullResonanceList")]
    genLogPath = "output/temp/genLog_true.txt"
    genLogPathQC = "output/temp/genLogQC_true.txt"
    resToyPaths['fullFit'] = "output/temp/true_model.root"
    resToyLatex['fullFit'] = "True model"
    
    if correlated:
        resToyPaths['fullFitQC'] = "output/temp/true_modelQC.root"
        resToyLatex['fullFitQC'] = "True model"
        os.system(f"./bin/genSample {nevtsToys} output/temp/true_modelQC.root output/true_modelQC- {int(correlated)} 1 > {genLogPathQC} 2>&1")
    
    os.system(f"./bin/genSample {nevtsToys} output/temp/true_model.root output/true_model- {int(correlated)} 1 > {genLogPath} 2>&1")

    fitComponentObjs = []
    fullFitInfo = resToyInfo('fullFit')
    fullFitInfo.fitFrac = 1
    fitComponentObjs.append(fullFitInfo)
    
    fitFracs = {}
    
    # Parsing for fit fractions
    for i in range(len(fitComponents)):
        fitFracFile = None
        if correlated:
            fitFracFile = open("output/temp/genLog_trueQC.txt", mode='r')
        else:
            fitFracFile = open("output/temp/genLog_true.txt", mode='r')
        lines = fitFracFile.readlines()
        for line in lines:
            targetLine = f"INFO in LauIsobarDynamics::initialise : Initial fit fraction for amplitude ({i},{i})"
            if targetLine in line:
                fitFrac = float(line.split(' ')[-1])
                fitFracs[fitComponents[i]] = fitFrac
    
    # Aggregating component information:
    for comp in fitComponents:
        compInfo = resToyInfo(comp)
        compInfo.fitFrac = fitFracs[comp]
        fitComponentObjs.append(compInfo)
    
    # Reading in data
    dataArr = uproot.open(fitSamplePath + ":DecayTree").arrays(["m12", "m13", "m23", "m12Sq", "m13Sq", "m23Sq"], library='pd')

    plotProjectionPlot(dataArr, fitComponentObjs, "m12", f"{fitSavePrefix}m12-projection.pdf")
    plotProjectionPlot(dataArr, fitComponentObjs, "m13", f"{fitSavePrefix}m13-projection.pdf")
    plotProjectionPlot(dataArr, fitComponentObjs, "m23", f"{fitSavePrefix}m23-projection.pdf")
        