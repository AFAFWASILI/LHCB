#include <iostream>
#include <vector>
#include <string>
#include <sstream>
#include <iomanip>
#include <filesystem>
#include <fstream>

#include "resonInfo.h"
#include "modelUtilities.h"
#include "buildResonanceModel.h"
#include "TFile.h"
#include "TTree.h"
#include "TROOT.h"
#include "TStyle.h"
#include "TColor.h"
#include "TCanvas.h"
#include "TPad.h"
#include "TLegend.h"
#include "TH1F.h"
#include "THStack.h"
#include "TTreeReader.h"

struct resToyInfo{
    TString resName;
    TString toySavePath;
    Double_t fitFrac;
};

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << " [fitResultPath] [fitSamplePath] [fitSavePrefix] [jointFit=0] [fitSamplePathQC]\n"
        << std::endl;
}

void defineColors(){
    // Set custom colors - Add here if more colors needed. The following tool https://medialab.github.io/iwanthue/ was used
    TColor* c1 = new TColor(9001,255,172,25);
    TColor* c2 = new TColor(9002,202,6,217);
    TColor* c3 = new TColor(9003,71,156,0);
    TColor* c4 = new TColor(9004,150,165,255);
    TColor* c5 = new TColor(9005,234,4,37);
    TColor* c6 = new TColor(9006,0,194,170);
    TColor* c7 = new TColor(9007,255,162,137);
    TColor* c8 = new TColor(9008,0,198,233);
}

void plotProjection(std::vector<resToyInfo> toyComponents, TString fullFitToyPath, TString dataPath, TString varname, TString savePath, TString xlabel, TString units, Double_t xmin, Double_t xmax, int nbins, int nbinsToys, bool plotComponents){

    gROOT->ProcessLine(".x Visualisation/lhcbStyle.C");
    gStyle->SetHistTopMargin(0.1);
    gStyle->SetTitleOffset(1., "X");
    gStyle->SetTitleFont(132, "X");
    gStyle->SetTitleOffset(1.1, "Y");
    gStyle->SetTitleFont(132, "Y");
    
    TString canvasName = varname+"_projection_canvas";
    TString dataHistName = "data_" + varname;
    TString fitHistName = "fitModel_" + varname;

    TFile* dataFile = new TFile(dataPath);
    TTree* dataTree = (TTree*)dataFile->Get("DecayTree");

    TFile* fitModelFile = new TFile(fullFitToyPath);
    TTree* fitModelTree = (TTree*)fitModelFile->Get("DecayTree");
    
    std::stringstream binsize;
    binsize << std::setprecision(2) << (xmax-xmin)/nbins;
    TString ylabel = "\\text{Events/}" + binsize.str() + "\\text{ }" + units;

    THStack* histStack = new THStack("hstack", ";" + xlabel + " " + units + ";" + ylabel + ";");

    // Initialising legend
    TLegend* leg = new TLegend(0.01, 0.35, 0.99, 0.80);
    leg->SetLineColor(0);
    leg->SetTextFont(132);
    leg->SetTextSize(0.12);

    // Drawing histograms
    // Data
    TH1F* dataHist = new TH1F(dataHistName, dataHistName, nbins, xmin, xmax);
    dataTree->Draw(varname+">>"+dataHistName);
    leg->AddEntry(dataHist, "Data", "P, E");

    // Full fit model
    TH1F* fitHist = new TH1F(fitHistName, fitHistName, nbinsToys, xmin, xmax);
    fitHist->SetLineColor(4);
    fitModelTree->Draw(varname+">>"+fitHistName);
    fitHist->Scale(dataHist->Integral("width")/fitHist->Integral("width"));
    histStack->Add(fitHist, "HISTC");
    leg->AddEntry(fitHist, "Fitted Model", "L");

    histStack->Add(dataHist, "P, E");
    
    if (plotComponents){
        // Plotting individual components
        for (int i = 0; i < toyComponents.size(); i++){
            resToyInfo componentInfo = toyComponents[i];
            if (componentInfo.fitFrac != 0.){
                TString compHistName = "comp" + std::to_string(i) + "_" + varname;
                TFile* compToyFile = new TFile(componentInfo.toySavePath);
                TTree* compToyTree = (TTree*)compToyFile->Get("DecayTree");

                TH1F* compHist = new TH1F(compHistName, compHistName, nbinsToys, xmin, xmax);
                compToyTree->Draw(varname+">>"+compHistName);
                compHist->SetLineColor(9001 + i);
                compHist->Scale(componentInfo.fitFrac*dataHist->Integral("width")/compHist->Integral("width"));
                histStack->Add(compHist, "HISTC");
                leg->AddEntry(compHist, componentInfo.resName, "L");
            }
        }
    }

    
    
    TCanvas* canvas = new TCanvas(canvasName, "", 3000, 1800);
    canvas->Draw();
    TPad* pad1 = new TPad("p1", "p1", 0., 0.01, 0.80, 0.99);
    pad1->Draw();
    pad1->cd();
    histStack->Draw("NOSTACK");
    canvas->cd();
    TPad* pad2 = new TPad("p2", "p2", 0.81, 0.01, 0.99, 0.99);
    pad2->SetBorderSize(0);
    pad2->Draw();
    pad2->cd();
    leg->Draw();
    canvas->Update();
    canvas->SaveAs(savePath);
}

std::vector<Double_t> readFitFrac(TString genLogPath){
    // Extracting fit fraction from fit model generation log
    std::vector<Double_t> fitFracVec;
    for (int i = 0; i < fitResonanceList.size(); i++){
        TString fitFracLine = "INFO in LauIsobarDynamics::initialise : Initial fit fraction for amplitude (" + std::to_string(i) + "," + std::to_string(i) + ") = ";
        std::ifstream fitToyLog;
        std::string line;
        
        fitToyLog.open(genLogPath);

        while (std::getline(fitToyLog, line)){
            if (line.find(fitFracLine) != std::string::npos){
                Double_t fitFrac = std::stof(line.substr(line.find_last_of(" ", line.size()-1)));
                fitFracVec.push_back(fitFrac);
            }
        }
    }
    return fitFracVec;
}

std::vector<Double_t> getModelFitFrac(std::vector<resonInfo> modelResInfoVec, int nevtsToy, TString toySavePath, TString logSavePath){
        std::freopen(logSavePath, "w", stdout);
        genToyHist(modelResInfoVec, nevtsToy, toySavePath); // Generate fit toy with correlated model
        std::fclose(stdout);

        std::vector<Double_t> fitFracVec;
        fitFracVec = readFitFrac(logSavePath);
        return fitFracVec;
}

int main(int argc, char* argv[]){
    using namespace std;

    if (argc < 4) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }

    TString fitResultPath = argv[1];
    //TString fitResultPath = "output/temp/fit-results.root";
    TString fitSamplePath = argv[2];
    TString fitSavePrefix = argv[3];
    bool jointFit = false;
    if (atoi(argv[4]) == 1){
        jointFit = true;
    }
    TString fitSamplePathQC = argv[5];

    TFile* sampleFile = new TFile(fitSamplePath);
    TFile* file = new TFile(fitResultPath);
    TTree* sampleTree = (TTree*)sampleFile->Get("DecayTree");

    // Reading in fit results to a vector
    int nevents = sampleTree->GetEntries();

    // Constructing resInfo struct with magnitudes and phases from fit
    vector<resonInfo> resInfoVec = readFitResults(fitResultPath, fitResonanceList); // List of resonInfo structs containing magnitude and phase of individual components from fit results
    vector<resonInfo> resInfoVecQC;

    vector<resToyInfo> toyInfoVec; // List of resToyInfo structs containing information about generated toys of each component
    vector<resToyInfo> toyInfoVecQC;
    
    int nevtsToy = 5000000; // Number of events in toys of fit model and component

    // Generating toy for full fit model
    TString fitToySavePath = "output/temp/total_fit.root";
    TString fitToySavePathQC = "output/temp/total_fit_QC.root";
    std::vector<Double_t> fitFracVec;
    std::vector<Double_t> fitFracVecQC;

    
    // Parse logs for fit fractions
    fitFracVec = getModelFitFrac(resInfoVec, nevtsToy, fitToySavePath, "output/temp/fitFracsFile.txt");

    // Do the same for QC model if fit results is from joint fit
    if (jointFit) {
        for (auto resInfo : resInfoVec){
            resInfoVecQC.push_back(getCorrelatedInfo(resInfo)); // Multiply by factor to account for quantum correlations
        }
        fitFracVecQC = getModelFitFrac(resInfoVecQC, nevtsToy, fitToySavePathQC, "output/temp/fitFracsFileQC.txt");
    }


    // Extracting fit fractions from fit log
    // Generating toys for each resonance component
    for (int i = 0; i < fitResonanceList.size(); i++){
        resonInfo compResInfo = getDefaultResInfo(fitResonanceList[i]);
        TString compSavePath = "output/temp/" + compResInfo.resName + "_fit.root";

        // Constructing struct to store toy information
        resToyInfo toyInfo;
        toyInfo.resName = compResInfo.resName;
        toyInfo.toySavePath = compSavePath;
        toyInfo.fitFrac = fitFracVec[i];
        toyInfoVec.push_back(toyInfo);

        //. Check if resonance is suppressed; only generate toy if it is not
        if (toyInfo.fitFrac != 0.){
            // Technically not necessary to set amplitude and phase to 1 and 0
            compResInfo.resAmp = 1;
            compResInfo.resPhase = 0;
            
            vector<resonInfo> componentResInfo = { compResInfo };
            // Check if toy exists for component before generating a new one - Should be a massive speedup for fit tests as generating distribution of 
            // individual resonances in phase space should not depend on any interference effects and therefore are independent of the magnitude and phase 
            std::filesystem::path compToyFilepath = compSavePath.Data();
            std::cout << compToyFilepath << "Exists : " << (std::filesystem::exists(compToyFilepath)) << std::endl;
            if (std::filesystem::exists(compToyFilepath) != 1){
                genToyHist(componentResInfo, nevtsToy, compSavePath); // Perform high-statistics generation of each component for more granularity in distribution
            }
            //std::cout << "INFO in plotDPProjection : Saving component toy to " << compSavePath << std::endl;
            
        }
        // Saving resonance toy info for QC sample 
        if (jointFit){
            toyInfo.fitFrac = fitFracVecQC[i];
            toyInfoVecQC.push_back(toyInfo);
        }

    }

    // Setting up plot colours
    defineColors();

    // Plotting projections
    /*
    if (jointFit){
        plotProjection(toyInfoVecQC, fitToySavePathQC, fitSamplePathQC, "m12", fitSavePrefix + "QC-m12-projection-fine.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV})", 3.6, 5, 50, 200, kTRUE);
        plotProjection(toyInfoVecQC, fitToySavePathQC, fitSamplePathQC, "m13", fitSavePrefix + "QC-m13-projection-fine.png","$m({D^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 200, kTRUE);
        plotProjection(toyInfoVecQC, fitToySavePathQC, fitSamplePathQC, "m23", fitSavePrefix + "QC-m23-projection-fine.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 200, kTRUE);

        //plotProjection(toyInfoVecQC, fitToySavePathQC, fitSamplePathQC, "m12", fitSavePrefix + "QC-m12-projection-coarse.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV})", 3.6, 5, 50, 50, kFALSE);
        //plotProjection(toyInfoVecQC, fitToySavePathQC, fitSamplePathQC, "m13", fitSavePrefix + "QC-m13-projection-coarse.png","$m({D^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 50, kFALSE);
        //plotProjection(toyInfoVecQC, fitToySavePathQC, fitSamplePathQC, "m23", fitSavePrefix + "QC-m23-projection-coarse.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 50, kFALSE);

        plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m12", fitSavePrefix + "UC-m12-projection-fine.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV})", 3.6, 5, 50, 200, kTRUE);
        plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m13", fitSavePrefix + "UC-m13-projection-fine.png","$m({D^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 200, kTRUE);
        plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m23", fitSavePrefix + "UC-m23-projection-fine.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 200, kTRUE);

        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m12", fitSavePrefix + "UC-m12-projection-coarse.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV})", 3.6, 5, 50, 50, kFALSE);
        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m13", fitSavePrefix + "UC-m13-projection-coarse.png","$m({D^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 50, kFALSE);
        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m23", fitSavePrefix + "UC-m23-projection-coarse.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 50, kFALSE);
    } else {
        plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m12", fitSavePrefix + "m12-projection-fine.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV})", 3.6, 5, 50, 200, kTRUE);
        plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m13", fitSavePrefix + "m13-projection-fine.png","$m({D^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 200, kTRUE);
        plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m23", fitSavePrefix + "m23-projection-fine.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 200, kTRUE);

        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m12", fitSavePrefix + "m12-projection-coarse.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV})", 3.6, 5, 50, 50, kFALSE);
        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m13", fitSavePrefix + "m13-projection-coarse.png","$m({D^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 50, kFALSE);
        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m23", fitSavePrefix + "m23-projection-coarse.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV})", 2.2, 3.5, 50, 50, kFALSE);

        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m12Sq", fitSavePrefix + "m12Sq-projection.png","$m({D^{0}\\bar{D}^{0}})$", "(\\text{GeV}^{2})", 13, 25, 50);
        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m13Sq", fitSavePrefix + "m13Sq-projection.png","$m({D^{0}K^{+}})$", "(\\text{GeV}^{2})",  4.5, 13, 50);
        //plotProjection(toyInfoVec, fitToySavePath, fitSamplePath, "m23Sq", fitSavePrefix + "m23Sq-projection.png","$m({\\bar{D}^{0}K^{+}})$", "(\\text{GeV}^{2})", 4.5, 13, 50);
    }
    */
    return 0;

   stdd:fclose(stdout);
}