#include <iostream>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <filesystem>
#include <omp.h>

#include "buildResonanceModel.h"
#include "modelUtilities.h"
#include "resonInfo.h"
#include "TROOT.h"
#include "TFile.h"
#include "TStyle.h"
#include "TTree.h"
#include "TCanvas.h"
#include "TH2F.h"
#include "TKDTreeBinning.h"
#include "TH2Poly.h"
#include "ROOT/RDataFrame.hxx"

LauSimpleFitModel* constructFitModel(std::vector<int> resonanceList, int nevts, bool squareDP, bool correlated, bool fixMass, bool fixWidth, int ntoys = 1){
    LauDaughters *daughters = new LauDaughters("B+", "D0_bar", "D0", "K+", squareDP);

    LauVetoes *vetoes = new LauVetoes();
    LauEffModel *effModel = new LauEffModel(daughters, vetoes);  // Efficiency model

    // Defining isobar decay model
    LauIsobarDynamics *sigModel = new LauIsobarDynamics(daughters, effModel);
    sigModel->setNarrowResonanceThreshold(0.03);
    std::vector<LauAbsCoeffSet*> uncorrelatedCoeffset = addUncorrelatedResonances(sigModel, fullResonanceList, fixMass, fixWidth); // Adding resonancees to isobar model
    std::vector<LauAbsCoeffSet*> coeffset;

    if (correlated) {
        std::vector<double> ampFactors = computeAmpFactors();
        int n = ampFactors.size();

        for (int i = 0; i < n; i++) {
            LauAbsCoeffSet* tempParam = uncorrelatedCoeffset[i];
            int resonanceID = fullResonanceList[i];

            // Multiplying amplitude by factor
            for (auto param : tempParam->getParameters()){
                if (param->name() == "A") {
                    param->value(param->value()*ampFactors[i]);
                    param->genValue(param->value()); // Setting generator (true) value so param_true in fit output is correct
                }
            }
            
            if (std::find(suppressedResonanceList.begin(), suppressedResonanceList.end(), resonanceID) != suppressedResonanceList.end()) { // Check if resonance is suppressed
                for (auto param : tempParam->getParameters()){
                    param->initValue(param->value()); // Fixing initial value so param not randomised at start of fit
                }
                // Fixing amplitude and phase
                tempParam->fixParameter("A");
                tempParam->fixParameter("Delta");
            }

            coeffset.push_back(tempParam);

        }
    } else {
        coeffset = uncorrelatedCoeffset;
    }

    sigModel->setASqMaxValue(9.0);
    LauSimpleFitModel* fitModel = new LauSimpleFitModel(sigModel);

    for (std::vector<LauAbsCoeffSet *>::iterator iter = coeffset.begin(); iter != coeffset.end(); ++iter) {
        fitModel->setAmpCoeffSet(*iter);
    }
    // LauParameter* nSigEvents = new LauParameter("signalEvents",nEventsData,-1000.0,100000.0,kTRUE);
    LauParameter *nSigEvents = new LauParameter("signalEvents", nevts, -1000.0, nevts, kTRUE);

    // Configuring the fit
    fitModel->setNSigEvents(nSigEvents);
    // fitModel->setNExpts( 1, 0 , kFALSE); // (kTRUE if you want generation within gaussian mean, see inc/LauFitObject.hh)
    // fitModel->setNExpts( nExpt, firstExpt, isToy );
    fitModel->setNExpts(ntoys, 0, kFALSE);
    fitModel->useAsymmFitErrors(kFALSE);
    fitModel->useRandomInitFitPars(kTRUE);
    fitModel->doPoissonSmearing(kTRUE);
    fitModel->doEMLFit(false);

    return fitModel;
}

LauSimpleFitModel* constructFitModel(std::vector<resonInfo> resonanceModel, int nevts, bool squareDP, bool correlated, bool fixMass, bool fixWidth, int ntoys = 1){
    // Overloaded constructFitModel to use vector of resonInfo so that the fit parameters have the correct fit values (i.e. generator values from resonInfo struct instead of the default)
    LauDaughters *daughters = new LauDaughters("B+", "D0_bar", "D0", "K+", squareDP);

    LauVetoes *vetoes = new LauVetoes();
    LauEffModel *effModel = new LauEffModel(daughters, vetoes);  // Efficiency model

    // Defining isobar decay model
    LauIsobarDynamics *sigModel = new LauIsobarDynamics(daughters, effModel);
    sigModel->setNarrowResonanceThreshold(0.03);

    std::vector<LauAbsCoeffSet*> uncorrelatedCoeffset;
    std::vector<LauAbsCoeffSet*> coeffset;

    for (auto reson : resonanceModel){
        LauAbsCoeffSet* resParams = addResonance(sigModel, reson, kTRUE, kTRUE);
        uncorrelatedCoeffset.push_back(resParams);
    }

    if (correlated) {
        std::vector<double> ampFactors = computeAmpFactors();
        int n = ampFactors.size();

        for (int i = 0; i < n; i++) {
            LauAbsCoeffSet* tempParam = uncorrelatedCoeffset[i];
            int resonanceID = fullResonanceList[i];

            // Multiplying amplitude by factor
            for (auto param : tempParam->getParameters()){
                if (param->name() == "A") {
                    param->value(param->value()*ampFactors[i]);
                    param->genValue(param->value()); // Setting generator (true) value so param_true in fit output is correct
                }
            }
            
            if (std::find(suppressedResonanceList.begin(), suppressedResonanceList.end(), resonanceID) != suppressedResonanceList.end()) { // Check if resonance is suppressed
                for (auto param : tempParam->getParameters()){
                    param->initValue(param->value()); // Fixing initial value so param not randomised at start of fit
                }
                // Fixing amplitude and phase
                tempParam->fixParameter("A");
                tempParam->fixParameter("Delta");
            }

            coeffset.push_back(tempParam);

        }
    } else {
        coeffset = uncorrelatedCoeffset;
    }

    sigModel->setASqMaxValue(9.0);
    LauSimpleFitModel* fitModel = new LauSimpleFitModel(sigModel);

    for (std::vector<LauAbsCoeffSet *>::iterator iter = coeffset.begin(); iter != coeffset.end(); ++iter) {
        fitModel->setAmpCoeffSet(*iter);
    }
    // LauParameter* nSigEvents = new LauParameter("signalEvents",nEventsData,-1000.0,100000.0,kTRUE);
    LauParameter *nSigEvents = new LauParameter("signalEvents", nevts, -1000.0, nevts, kTRUE);

    // Configuring the fit
    fitModel->setNSigEvents(nSigEvents);
    // fitModel->setNExpts( 1, 0 , kFALSE); // (kTRUE if you want generation within gaussian mean, see inc/LauFitObject.hh)
    // fitModel->setNExpts( nExpt, firstExpt, isToy );
    fitModel->setNExpts(ntoys, 0, kFALSE);
    fitModel->useAsymmFitErrors(kFALSE);
    fitModel->useRandomInitFitPars(kTRUE);
    fitModel->doPoissonSmearing(kTRUE);
    fitModel->doEMLFit(false);

    return fitModel;
}

TKDTreeBinning* computeKDBins(TString dataPath, int nevtsData, int nbins){
    // Reading in data as a vector
    ROOT::RDataFrame df("DecayTree", dataPath);
    std::vector<Double_t> dataVec;
    auto m12Vec = df.Take<Double_t>("m12");
    auto m23Vec = df.Take<Double_t>("m23");

    for (auto val : m12Vec) {
        dataVec.push_back(val);
    }

    for (auto val : m23Vec) {
        dataVec.push_back(val);
    }

    TKDTreeBinning* kdBins = new TKDTreeBinning(nevtsData, 2, dataVec, nbins);

    return kdBins;
}

double computeChiSquare(TString dataPath, TString fitToyPath, TString plotSaveDir, bool savePlots, int exptNum, TString binDataPath = ""){
    // Reading in test sample
    TFile* dataFile = new TFile(dataPath);
    TTree* dataTree = (TTree*)dataFile->Get("DecayTree");
    int nevtsData = dataTree->GetEntries();

    TString toyPath = fitToyPath;
    TFile* toyFile = new TFile(toyPath);

    // Loading plotting style
    gROOT->ProcessLine(".x Visualisation/lhcbStyle.C");
    gStyle->SetTitleOffset(1.2, "X");
    gStyle->SetTitleOffset(1.2, "Y");
    gStyle->SetLabelSize(0.04, "X");
    gStyle->SetTitleSize(0.04, "X");
    gStyle->SetLabelSize(0.04, "Y");
    gStyle->SetTitleSize(0.04, "Y");
    gStyle->SetLabelSize(0.04, "Z");
    gStyle->SetTitleSize(0.04, "Z");

    // Configuring plots
    int nbinsx = 4;
    int nbinsy = 4;
    Double_t m12SqLow = 3.6;
    Double_t m12SqHigh = 5.;
    Double_t m23SqLow = 2.2;
    Double_t m23SqHigh = 3.5;
    TString xlabel = "$m({D^{0}\\bar{D}^{0}})$ (\\text{GeV})";
    TString ylabel = "$m({\\bar{D}^{0}}K^{+})$ (\\text{GeV})";

    TString histLabel = ";" + xlabel + ";" + ylabel;

    std::vector<Double_t> binXmin{ 3.6, 3.6, 3.6, 3.6, 3.912462233712884, 3.912462233712884, 3.912462233712884, 3.912462233712884, 4.041526467933984, 4.041526467933984, 4.041526467933984, 4.041526467933984, 4.410068752279903, 4.410068752279903, 4.410068752279903, 4.410068752279903 };
    std::vector<Double_t> binXmax{ 3.912462233712884, 3.912462233712884, 3.912462233712884, 3.912462233712884, 4.041526467933984, 4.041526467933984, 4.041526467933984, 4.041526467933984, 4.410068752279903, 4.410068752279903, 4.410068752279903, 4.410068752279903, 5, 5, 5, 5 };
    std::vector<Double_t> binYmin{ 2.2, 3.04578575881521, 3.1141384979869224, 3.3245245945594015, 2.2, 2.824876092731319, 2.8976956751394005, 3.2136300491044887, 2.2, 2.585691040555959, 2.722582829208836, 3.069846566271542, 2.2, 2.5686827716784473, 2.597315163667629, 2.7112536877533873 };
    std::vector<Double_t> binYmax{ 3.04578575881521, 3.1141384979869224, 3.3245245945594015, 3.5, 2.824876092731319, 2.8976956751394005, 3.2136300491044887, 3.5, 2.585691040555959, 2.722582829208836, 3.069846566271542, 3.5, 2.5686827716784473, 2.597315163667629, 2.7112536877533873, 3.5 };

    TH2Poly* m12m23Data = new TH2Poly("m12m23Data", histLabel, 3.6, 5., 2.2, 3.5);
    TH2Poly* m12m23Toy = new TH2Poly("m12m23Toy", histLabel, 3.6, 5., 2.2, 3.5);
    TH2Poly* m12m23Chisq = new TH2Poly("m12m23Chisq", histLabel, 3.6, 5., 2.2, 3.5);

    int nbins = binXmin.size();

    // Initialising bins
    for (int i = 0; i < nbins; i++){
        m12m23Data->AddBin(binXmin[i], binYmin[i], binXmax[i], binYmax[i]);
        m12m23Toy->AddBin(binXmin[i], binYmin[i], binXmax[i], binYmax[i]);
        m12m23Chisq->AddBin(binXmin[i], binYmin[i], binXmax[i], binYmax[i]);
    }

    // Filling histogram bins from data
    TTreeReader dataReader("DecayTree", dataFile);
    TTreeReaderValue<Double_t> m12Data(dataReader, "m12");
    TTreeReaderValue<Double_t> m23Data(dataReader, "m23");
    while (dataReader.Next()){
        m12m23Data->Fill(*m12Data, *m23Data);
    }

    TTreeReader toyReader("DecayTree", toyFile);
    TTreeReaderValue<Double_t> m12Toy(toyReader, "m12");
    TTreeReaderValue<Double_t> m23Toy(toyReader, "m23");
    while (toyReader.Next()){
        //std::cout << *m12Toy << " " << *m23Toy << std::endl;
        m12m23Toy->Fill(*m12Toy, *m23Toy);
    }

    // Normalising toy histogram
    m12m23Toy->Scale(m12m23Data->Integral()/m12m23Toy->Integral());


    Double_t totalChisq = 0;
    for (int i = 1; i <= nbins; i++){
        Double_t binChisqVal = pow((m12m23Data->GetBinContent(i) - m12m23Toy->GetBinContent(i)), 2)/m12m23Toy->GetBinContent(i);
        //std::cout << "bin " << i << " chi2 " << binChisqVal << std::endl;
        m12m23Chisq->SetBinContent(i, binChisqVal);
        totalChisq += binChisqVal;
        //std::cout << binChisqVal << std::endl;
    }

    // Making plots
    if (savePlots) {
        TCanvas* canvasKDBinned = new TCanvas("canvasKDBinned", "", 1600, 1200);
        canvasKDBinned->cd();
        m12m23Data->Draw("TEXT");

        TCanvas* canvasKDBinnedToy = new TCanvas("canvasKDBinnedToy", "", 1600, 1200);
        canvasKDBinnedToy->cd();
        m12m23Toy->Draw("TEXT");
        
        TString chisqTitle = "$\\chi^{2} = $" + std::to_string(totalChisq);
        TCanvas* canvasKDBinnedChisq = new TCanvas("canvasKDBinnedChisq", "", 1600, 1200);
        canvasKDBinnedChisq->cd();
        canvasKDBinnedChisq->SetRightMargin(0.14);
        canvasKDBinnedChisq->SetTopMargin(0.08);
        canvasKDBinnedChisq->Update();
        m12m23Chisq->SetTitle(chisqTitle);
        m12m23Chisq->Draw("COLZ TEXT");

        canvasKDBinned->SaveAs(plotSaveDir + "origFitToy.png");
        canvasKDBinnedToy->SaveAs(plotSaveDir + "refitToy.png");
        canvasKDBinnedChisq->SaveAs(plotSaveDir + "kdBinnedChisq.png");

        delete canvasKDBinned;
        delete canvasKDBinnedChisq;
        delete canvasKDBinnedToy;
    }
    
    // Deleting pointers at end of the function
    delete dataTree;
    delete dataFile;
    delete toyFile;
    delete m12m23Chisq;
    delete m12m23Data;
    delete m12m23Toy;
    return totalChisq;
}

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << " [fitResultsPath] [saveDir] [binDataPath] [correlated=0]\n"
        << std::endl;
}

int main(int argc, char** argv){
    if (argc < 5) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }

    // Script for calculating chi square of fit performed to toy generated with parameters obtained from fit
    TString fitResultsPath = argv[1];
    TString saveDir = argv[2];
    TString binDataPath = argv[3]; // Option to specify a data file to bin on
    bool correlated = argv[4];

    int nevtsToys = 5000;
    int nevtsPDF = 100000;
    int nToys = 5;

    TString fitResultToyPath = saveDir + "origFitToy.root"; // Toy generated from original fit results
    TString refitResultsPath = saveDir + "refitResults.root"; // Refit result

    // Reading in fit results
    std::vector<resonInfo> fitModel = readFitResults(fitResultsPath);
    genToyHist(fitModel, nevtsToys, fitResultToyPath, nToys); // Generating toy from fit results

    // Performing fit to generated toy
    // Setting up fit model
    LauSimpleFitModel* refitModel = constructFitModel(fitModel, nevtsToys, kFALSE, kFALSE, kTRUE, kTRUE, nToys);

    // Running refit - TODO: Check if fit converges
    refitModel->run("fit", fitResultToyPath, "DecayTree", refitResultsPath, "");

    // Creating file to store chi-square values
    char* chisqFilePath = "output/FitQuality/chisqVals.csv";
    std::filesystem::path chisqSysPath = chisqFilePath;
    if (std::filesystem::exists(chisqSysPath)){
        std::remove(chisqFilePath);
    }
    std::ofstream outfile;
    outfile.open(chisqFilePath);
    outfile << "exptNum, chi2 \n";

    // Separate loop for generating PDF toys for parallelisation as this is the most time consuming part
    #pragma omp parallel for num_threads(8)
    for (int exptNum = 0; exptNum < nToys; exptNum++){
        TString exptSaveDir = saveDir + "refit-" + std::to_string(exptNum) + "-";
        TString refitPDFToyPath = exptSaveDir + "PDFToy.root"; // Toy generated from refit

        // Starting a sub-process to generate from fit instead of directly calling Laura++ to avoid memory leak
        TString genCommand = "./bin/genFromFit " + refitResultsPath + " " + refitPDFToyPath + " " + std::to_string(nevtsPDF) + " " + std::to_string(exptNum) + " " + std::to_string(1);
        std::system(genCommand);
    }

    // Computing chi square values and saving into csv
    for (int exptNum = 0; exptNum < nToys; exptNum++){
        TString exptSaveDir = saveDir + "refit-" + std::to_string(exptNum) + "-";
        TString refitPDFToyPath = exptSaveDir + "PDFToy.root"; // Toy generated from refit

        double chisqVal;
        // Calculating chi square
        if (binDataPath != ""){
            std::cout << "INFO in ndofToys : Performing adaptive binning in " << binDataPath << std::endl;
            chisqVal = computeChiSquare(fitResultToyPath, refitPDFToyPath, exptSaveDir, kTRUE, exptNum, binDataPath);
        } else { 
            std::cout << "INFO in ndofToys : No data file specified for binning, performing adaptive binning on fit result toy" << std::endl;
            chisqVal = computeChiSquare(fitResultToyPath, refitPDFToyPath, exptSaveDir, kFALSE, exptNum);
        }

        // Writing chi square value
        outfile << exptNum << "," << chisqVal << "\n";
    }

    outfile.close();
    return 0;
}