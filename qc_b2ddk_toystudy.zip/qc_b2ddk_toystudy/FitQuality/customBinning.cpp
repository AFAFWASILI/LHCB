#include <iostream>
#include <cmath>

#include "buildResonanceModel.h"
#include "modelUtilities.h"
#include "TROOT.h"
#include "TStyle.h"
#include "TFile.h"
#include "TTree.h"
#include "TCanvas.h"
#include "TLatex.h"
#include "TH2F.h"
#include "TKDTreeBinning.h"
#include "TH2Poly.h"
#include "TTreeReader.h"
#include "ROOT/RDataFrame.hxx"
#include "BinningScheme.h"

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << " [fitDataPath] [fitResultsPath] [savePrefix]\n"
        << std::endl;
}

int main(int argc, char **argv){
    if (argc < 3) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }
    // Reading in test sample
    //TString dataPath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-testSample.root";
    //TString fitResultsPath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-fitHist-10.root";
    TString dataPath = argv[1];
    TString fitResultsPath = argv[2];
    TString savePrefix = argv[3];

    TFile* dataFile = new TFile(dataPath);
    TTree* dataTree = (TTree*)dataFile->Get("DecayTree");
    int nevtsData = dataTree->GetEntries();

    TString toyPath = savePrefix + "origFitToy.root";
    TFile* toyFile = new TFile(toyPath);

    // Loading plotting style
    gROOT->ProcessLine(".x Visualisation/lhcbStyle.C");
    gStyle->SetTitleOffset(1.2, "X");
    gStyle->SetTitleOffset(1.2, "Y");
    gStyle->SetLabelSize(0.04, "X");
    gStyle->SetTitleSize(0.04, "X");
    gStyle->SetLabelSize(0.04, "Y");
    gStyle->SetTitleSize(0.04, "Y");
    gStyle->SetLabelSize(0.04, "Z");
    gStyle->SetTitleSize(0.04, "Z");

    // Configuring plots
    int nbinsx = 4;
    int nbinsy = 4;
    Double_t m12SqLow = 3.6*3.6;
    Double_t m12SqHigh = 5.*5.;
    Double_t m23SqLow = 2.2*2.2;
    Double_t m23SqHigh = 3.5*3.5;
    TString xlabel = "$m^{2}({D^{0}\\bar{D}^{0}})$ (\\text{GeV}/c^{2})^{2}";
    TString ylabel = "$m^{2}(D^{0}K^{+})$ (\\text{GeV}/c^{2})^{2}";

    TString histLabel = ";" + xlabel + ";" + ylabel;

    TH2Poly* m12m23Data = new TH2Poly("m12m23Data", histLabel, 3.6*3.6, 5.*5., 2.2*2.2, 3.5*3.5);
    TH2Poly* m12m23Toy = new TH2Poly("m12m23Toy", histLabel, 3.6*3.6, 5.*5., 2.2*2.2, 3.5*3.5);
    TH2Poly* m12m23Chisq = new TH2Poly("m12m23Chisq", histLabel, 3.6*3.6, 5.*5., 2.2*2.2, 3.5*3.5);

    int nbins = binXmin.size();

    // Initialising bins
    for (int i = 0; i < nbins; i++){
        m12m23Data->AddBin(binXmin[i], binYmin[i], binXmax[i], binYmax[i]);
        m12m23Toy->AddBin(binXmin[i], binYmin[i], binXmax[i], binYmax[i]);
        m12m23Chisq->AddBin(binXmin[i], binYmin[i], binXmax[i], binYmax[i]);
    }
    /*
    for (int i = 1; i <= kdBins->GetNBins(); i++){
        m12m23Data->SetBinContent(i, kdBins->GetBinContent(((i - 1))));
    }
    */
    // Filling histogram bins from data
    TTreeReader dataReader("DecayTree", dataFile);
    TTreeReaderValue<Double_t> m12Data(dataReader, "m12Sq");
    TTreeReaderValue<Double_t> m23Data(dataReader, "m23Sq");
    while (dataReader.Next()){
        m12m23Data->Fill(*m12Data, *m23Data);
    }

    TTreeReader toyReader("DecayTree", toyFile);
    TTreeReaderValue<Double_t> m12Toy(toyReader, "m12Sq");
    TTreeReaderValue<Double_t> m23Toy(toyReader, "m23Sq");
    while (toyReader.Next()){
        //std::cout << *m12Toy << " " << *m23Toy << std::endl;
        m12m23Toy->Fill(*m12Toy, *m23Toy);
    }

    // Normalising toy histogram
    std::cout << m12m23Data->Integral("width") << " " << m12m23Toy->Integral("width") << std::endl;
    m12m23Toy->Scale(m12m23Data->Integral("width")/m12m23Toy->Integral("width"));


    Double_t totalChisq = 0;
    for (int i = 1; i <= nbins; i++){
        //std::cout << m12m23Data->GetBinContent(i) << " " << m12m23Toy->GetBinContent(i) << std::endl;
        Double_t binChisqVal = pow((m12m23Data->GetBinContent(i) - m12m23Toy->GetBinContent(i)), 2)/m12m23Toy->GetBinContent(i);
        //std::cout << "bin " << i << " chi2 " << binChisqVal << std::endl;
        m12m23Chisq->SetBinContent(i, binChisqVal);
        totalChisq += binChisqVal;
        //std::cout << binChisqVal << std::endl;
    }

    TCanvas* canvasKDBinned = new TCanvas("canvasKDBinned", "", 1600, 1200);
    canvasKDBinned->cd();
    m12m23Data->Draw("TEXT");
    canvasKDBinned->SaveAs(savePrefix + "binnedData.png");

    TCanvas* canvasKDBinnedToy = new TCanvas("canvasKDBinnedToy", "", 1600, 1200);
    canvasKDBinnedToy->cd();
    m12m23Toy->Draw("TEXT");
    canvasKDBinnedToy->SaveAs(savePrefix + "binnedToy.png");

    TString chisqTitle = "$\\chi^{2} = $" + std::to_string(totalChisq);
    TCanvas* canvasKDBinnedChisq = new TCanvas("canvasKDBinned", "", 1600, 1200);
    canvasKDBinnedChisq->cd();
    canvasKDBinnedChisq->SetRightMargin(0.14);
    canvasKDBinnedChisq->SetTopMargin(0.08);
    canvasKDBinnedChisq->Update();
    m12m23Chisq->SetTitle(chisqTitle);
    m12m23Chisq->Draw("COLZ TEXT");
    canvasKDBinnedChisq->SaveAs(savePrefix + "binnedChisq.png");
}