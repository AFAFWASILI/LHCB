import numpy as np
import matplotlib.pyplot as plt
import mplhep
import awkward as ak
import uproot
import os
import shutil
import sys
import glob
import re
import argparse
from scipy.stats import chi2
from scipy.optimize import minimize_scalar, Bounds

def adaBinning(df, varname, nbins, min, max):
    sortedArr = sorted(df[varname].to_list())
    splitArr = np.array_split(sortedArr, nbins)
    binEdges = []
    
    for bin in splitArr:
        binEdges.append(bin[0])
    binEdges[0] = min
    binEdges.append(max)
    return binEdges

def arrToVec(arr):
    arrStr = "{ "
    for i in range(len(arr)):
        if i != len(arr)-1:
            arrStr += f"{arr[i]}, "
        else:
            arrStr += f"{arr[i]} "
    arrStr += "}"
    return arrStr

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Calculates binned chi2 for a given set of fit results")
    parser.add_argument('dataFilePath', action='store', metavar='dataFilePath', type=str, help='Path to data file')
    parser.add_argument('binFilePath', action='store', metavar='binFilePath', type=str, help='Path to file to perform binning on')
    parser.add_argument('nominalFitPath', action='store', metavar='nominalFitPath', type=str, help='Path to fit results')
    parser.add_argument('outputSavePrefix', action='store', metavar='outputSavePrefix', type=str, default="output/Fitquality/correctedFit", help='Save tag for files produced from chi2 calculation')
    parser.add_argument('fitModelIndPath', action='store', metavar='fitModelIndPath', type=str, default='', help='Path to file containing resonance indices in amplitude model')
    
    args = vars(parser.parse_args())
    dataFilePath = args['dataFilePath']
    binFilePath = args['binFilePath']
    nominalFitPath = args['nominalFitPath']
    outputSavePrefix = args['outputSavePrefix']
    fitModelIndPath = args['fitModelIndPath']
    fitResultsPath = nominalFitPath
    # Configuration
    #dataFilePath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-testSample.root"
    binSchemeSavePath = "FitQuality/BinningScheme.h"
    #nominalFitPath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-fitHist-104.root"
    #fitResultsPath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-fitHist-104.root"
    #outputSavePrefix = "output/FitQuality/nominalFit-"
    binFilePath = dataFilePath # Currently binning on data
    
    #outputSavePrefix = "output/FitQuality/correctedFit-"
    #fitResultsPath = "output/FitBias/correctedFitParams.root"
    
    # Creating a high-statistics toy to bin on from nominal fit results
    #binFilePath = "output/FitQuality/binningSample.root"
    #os.system(f"./bin/genFromFit {nominalFitPath} {binFilePath} {100000} {0} {1} {0} ''")
    
    #region Calculate binning scheme
    binEvts = uproot.open(binFilePath + ":DecayTree")
    
    nbins = 6 # Number of bins per axis
    xvar = "m12Sq"
    xmin = 12.9
    xmax = 25
    yvar = "m23Sq"
    ymin = 4.8
    ymax = 12.3

    dpMasses = binEvts.arrays(["m12Sq", "m13Sq", "m23Sq"], library="pd")
    
    # Computing bin edges in x axis by splitting sorted list into (roughly) equally sized parts
    xbins = adaBinning(dpMasses, xvar, nbins, xmin, xmax)
    ybins = []
    bincount = 0
    
    for i in range(nbins):
        # Code for selecting the correct x bin
        xbinDF = None
        xminBin = xbins[i]
        xmaxBin = xbins[i+1]
        
        # Bound should be inclusive for upper edge of histogram
        if (i != nbins - 1):
            xbinDF = dpMasses[(dpMasses[xvar] >= xminBin) & (dpMasses[xvar] < xmaxBin)]
        else:
            xbinDF = dpMasses[(dpMasses[xvar] >= xminBin) & (dpMasses[xvar] <= xmaxBin)]
            

        # Computing bin edges in y axis

        colYbins = adaBinning(xbinDF, yvar, nbins, ymin, ymax)
        ybins.append(colYbins)
        
        subcount = 0
        for j in range(nbins):
            binDF = None
            yminBin = ybins[i][j]
            ymaxBin = ybins[i][j+1]
            
            # Bound should be inclusive for upper edge of histogram
            if (j != nbins - 1):
                binDF = xbinDF[(xbinDF[yvar] >= yminBin) & (xbinDF[yvar] < ymaxBin)]
            else:
                binDF = xbinDF[(xbinDF[yvar] >= yminBin) & (xbinDF[yvar] <= ymaxBin)]
                
    # Saving binning scheme
    saveBinXmin = []
    saveBinXmax = []
    saveBinYmin = []
    saveBinYmax = []
    for i in range(nbins):
        for j in range(nbins):
            saveBinXmin.append(xbins[i])
            saveBinXmax.append(xbins[i+1])
            saveBinYmin.append(ybins[i][j])
            saveBinYmax.append(ybins[i][j+1])

    with open(binSchemeSavePath, "w") as outfile:
        outfile.write("#include <vector>" + '\n')
        outfile.write("#ifndef ADABIN_EDGES" + '\n')
        outfile.write("#define ADABIN_EDGES" + '\n')
        outfile.write("std::vector<double> binXmin" + arrToVec(saveBinXmin) + ';\n')
        outfile.write("std::vector<double> binXmax" + arrToVec(saveBinXmax) + ';\n')
        outfile.write("std::vector<double> binYmin" + arrToVec(saveBinYmin) + ';\n')
        outfile.write("std::vector<double> binYmax" + arrToVec(saveBinYmax) + ';\n')
        outfile.write("#endif")
        outfile.close()
    
    # Remove old executable compiled with old binning scheme
    print("Recompiling chi2 calculation script")
    if os.path.exists("bin/customBinning"):
        os.remove("bin/customBinning")
    os.system("make bin/customBinning") #Recompile with new header containing new binning scheme
    #endregion
    
    #region Computing binned chi-square values
    
    # Generating toy from fit
    os.system(f"./bin/genFromFit {fitResultsPath} {outputSavePrefix}origFitToy.root {1000000} {0} {1} {0} {fitModelIndPath}") # Currently this would use file identical to binning file as fit toy. Should be fine for now as both are generated from the same model.
    
    os.system(f"./bin/customBinning {dataFilePath} {fitResultsPath} {outputSavePrefix}")
    