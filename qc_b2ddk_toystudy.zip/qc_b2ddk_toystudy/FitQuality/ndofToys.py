import numpy as np
import matplotlib.pyplot as plt
import mplhep
import awkward as ak
import uproot
import os
import shutil
import sys
import glob
import re
from scipy.stats import chi2
from scipy.optimize import minimize_scalar, Bounds

if __name__ == "__main__":
    chisqFilePath = "output/FitQuality/chisqVals.csv"
    plotResiduals = True
    chisqResults = np.genfromtxt(chisqFilePath, dtype=float, delimiter=',', names=True)
    chisqList = chisqResults['chi2']
    #chisqList = chi2.rvs(14, size=10000)
    chisqBins = 26
    numParams = 18
    mplhep.styles.use("LHCb2")
    
    # Computing bounds for chi square
    ndofLow = chisqBins - numParams - 1
    ndofHigh = chisqBins - 1
    
    # Plotting chi square distribution
    fig,ax = plt.subplots()
    plt.hist(chisqList, bins=40)
    plt.xlabel(r"Toy $\chi^{2}$")
    plt.ylabel("Num. of toys")
    plt.savefig("output/FitQuality/chisqHist.png")
    plt.close()
    

    # Computing residual between p-value distribution and a flat distribution as function of Ndof
    def getResiduals(ndof):
        pvalDistribution = chi2.sf(chisqList, ndof)
        ntoys = len(pvalDistribution)
        nbins = 20
        binHeights, binEdges = np.histogram(pvalDistribution, bins=nbins, range=[0,1])
        expectedBinHeight = ntoys/nbins
        residual = np.sum((binHeights - expectedBinHeight)**2)
        return residual
    
    # Minimising residual as function of ndof to get value corresponding to the flattest distribution
    optimizeResult = minimize_scalar(getResiduals, bounds=(ndofLow, ndofHigh))
    print(optimizeResult)

    # Plotting residual as function of ndof
    if plotResiduals:
        xrange = np.linspace(ndofLow, ndofHigh, 50)
        yvals = [getResiduals(ndof) for ndof in xrange]
        plt.plot(xrange, yvals)
        plt.xlabel(r'Residual$^{2}$')
        plt.ylabel(r'$N_{\text{dof}}$')
        #plt.axvline(14, c='r', label=r'True $N_{\text{dof}}$ = 14.00')
        plt.axvline(optimizeResult.x, c='b', label=r'Fit $N_{\text{dof}}$ = ' + str(round(optimizeResult.x, 2)))
        leg = plt.legend(loc='upper right', bbox_to_anchor=(0.9, 1.0))
        plt.savefig("output/FitQuality/ndofResidual.png")
        plt.close()
        
        # Plot p-value distribution after fit
        pvalDistribution = chi2.sf(chisqList, optimizeResult.x)
        plt.hist(pvalDistribution, bins=20, range=[0,1])
        plt.xlabel("p-value")
        plt.ylabel("Num. of toys")
        plt.title(r'$\chi^{2} = $' + str((round(optimizeResult.x, 2))))
        plt.savefig(r'output/FitQuality/pvalDistribution.png')
        plt.close()
        