import os
import subprocess
import time
import argparse
import uproot
from glob import glob

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Runs a simultaneous fit on a correlated and uncorrelated sample for the purpose of calculating fit bias corrections')
    parser.add_argument('--tupleDir', action='store', type=str, help='Path to directory to store tuples from fit')
    parser.add_argument('--logDir', action='store', type=str, help='Path to directory to store logs from fit')
    parser.add_argument('--saveLabel', action='store', type=str, help='Save label for tuples and logs. Files saved in the following path: fileDir/saveLabel-suffix.ext')
    parser.add_argument('--toysPathUC', action='store', type=str, help='Path to tuple containing uncorrelated toys')
    parser.add_argument('--toysPathQC', action='store', type=str, help='Path to tuple containing correlated toys')
    parser.add_argument('--resIndFile', action='store', type=str, help='Path to file containing resonance indices of configuration')
    parser.add_argument('--nToys', action='store', type=int, help='Number of toys in sample')
    args = vars(parser.parse_args())

    tupleDir = args['tupleDir']
    logDir = args['logDir']
    saveLabel = args['saveLabel']
    toysPathUC = args['toysPathUC']
    toysPathQC = args['toysPathQC']
    resIndFile = args['resIndFile']
    ntoys = args['nToys']
    
    
    # Performing simultaneous fit
    coordinatorLogPath = f"{logDir}/{saveLabel}-coordinatorLog.log"
    coordinatorOutputPath = f"{tupleDir}/{saveLabel}-coordinatorResults.root"
    taskUCLogPath = f"{logDir}/{saveLabel}-UCfitLog.log"
    taskQCLogPath =f"{logDir}/{saveLabel}-QCfitLog.log"
    
    
    # Starting fit coordinator
    coordinatorProcess = subprocess.Popen(f"./bin/jointFitCoordinator {coordinatorOutputPath} {ntoys} 0 > {coordinatorLogPath} 2>&1 & sleep 5", shell=True)
    time.sleep(1)
    # Wait until coordinator is initialised and waiting for connections
    nLinesCoordinator = sum(1 for _ in open(coordinatorLogPath))
    while nLinesCoordinator < 1:
        time.sleep(5)
        print(nLinesCoordinator)
        nLinesCoordinator = sum(1 for _ in open(coordinatorLogPath))
    port = 0
    
    with open(coordinatorLogPath) as coordinatorLog:
        for line in coordinatorLog:
            if "INFO in LauSimFitCoordinator::initSockets : Waiting for connection" in line:
                port = line.split()[-1]
    
    # Starting joint fit tasks
    subprocess.run(f"./bin/fitConfigurationTask {toysPathUC} {tupleDir}/{saveLabel}-UC- 0 {ntoys} {resIndFile} localhost {port} > {taskUCLogPath} 2>&1 & sleep 1", shell=True)
    subprocess.run(f"./bin/fitConfigurationTask {toysPathQC} {tupleDir}/{saveLabel}-QC- 1 {ntoys} {resIndFile} localhost {port} > {taskQCLogPath} 2>&1 & sleep 1", shell=True)
    coordinatorProcess.wait()
    
    # Checking for changes in coordinator log file size to see if fit finished running. This is needed because if this reaches the end of the script before the fit finishes, the main script for bias calculations will start another set of fits, leading to memory leaks. 
    coordLogFileSize = os.path.getsize(coordinatorLogPath)
    newCoordLogFileSize = os.path.getsize(coordinatorLogPath) + 1
    while newCoordLogFileSize != coordLogFileSize:
        coordLogFileSize = newCoordLogFileSize # Read in file size
        time.sleep(5) # Wait 3s
        newCoordLogFileSize = os.path.getsize(coordinatorLogPath)
    
    #print(f"Fit with log {coordinatorLogPath} finished running. Final line {subprocess.check_output(['tail', '-1', coordinatorLogPath])}")