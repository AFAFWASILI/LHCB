import os
import uproot
import mplhep
#import zfit
import pandas as pd
import numpy as np
import scipy.stats
import matplotlib.pyplot as plt
from warnings import simplefilter
from glob import glob
from multiprocessing import Pool

def getBestNLL(fileList):
    # Extracting best NLL
    fitNLLDict = {}
    for file in fileList:
        with uproot.open(file + ":fitResults") as fitResults:
            fitNLLDict[file] = fitResults["NLL"].array()[0]
    
    bestFitFile = min(fitNLLDict, key=fitNLLDict.get)
    bestFitNLL = fitNLLDict[bestFitFile]
    return bestFitFile, bestFitNLL

if __name__ == "__main__":
    
    parentOutdir = "output/AmpModel_SimFit"
    fitDataPathUC = "output/FittingTests/UC_Only/Tuples/UC-5000evts-testSample.root"
    fitDataPathQC = "output/FittingTests/QC_Only/Tuples/QC-5000evts-testSample.root"
    resultSavePath = f"{parentOutdir}/deltaNLL.txt"
    
    nevtsToysUC = 1000
    nevtsToysQC = 1000
    ntoys = 50
    nfits = 2
    #baselineConfig = [1, 2, 8, 5, 38, 3]
    #baselineConfig = [2, 8]
    baselineConfig = [1, 2, 8, 5]
    modelConfigurations = {
        "baseline" : baselineConfig, # Baseline model with only chi_c2(2P)/psi(3770)
        #"incl_psi4040" : baselineConfig + [3], # Baseline + psi(4040)
        #"incl_psi4160" : baselineConfig + [4], # Baseline + psi(4415)
        #"incl_psi4415" : baselineConfig + [5],
        #"incl_all_psi" : [2, 7, 8, 1, 3, 4, 5], # Baseline + psi(4160) + psi(4415)
        "incl_chi_c0" : baselineConfig + [38], # Baseline + chi_c0
        #"incl_ds_2573" : baselineConfig + [7],
        #"incl_ds_2700" : baselineConfig + [8]
        #"incl_chi_c0_all_psi" : [2, 38, 7, 8, 1, 3, 4, 5], # Baseline + chi_c0 + psi(4160) + psi(4415)
        #"incl_random" : baselineConfig + [13]
    }
    
    # Suppressing Pandas warnings
    simplefilter(action="ignore", category=pd.errors.PerformanceWarning)
    
    baselineNLL = 0
    baselineNdof = 0
    baselineTuplesDir = ""
    baselineResultsDir = ""
    fileLines = []
    
    # Performing fits for each configuration
    for modelKey in modelConfigurations:
        modelResInd = modelConfigurations[modelKey]
        
        # Setting up output directories for model configuration
        configOutdir = f"{parentOutdir}/{modelKey}"
        tuplesDir = f"{configOutdir}/Tuples"
        logsDir = f"{configOutdir}/Logs"
        resultsDir = f"{configOutdir}/Results"
        
        if modelKey == "baseline":
            baselineTuplesDir = tuplesDir
            baselineResultsDir = resultsDir

        if not(os.path.isdir(configOutdir)):
            os.mkdir(configOutdir)
        
        for subdir in [tuplesDir, logsDir, resultsDir]:
            if not(os.path.isdir(subdir)):
                os.mkdir(subdir)
                
        modelFile = f"{tuplesDir}/configIndList.txt"
        modelIndFile = open(modelFile, "w")
        for ind in modelResInd:
            modelIndFile.write(str(ind) + '\n')
        modelIndFile.close()
        
        
        # Performing test fits to data
        def runDataFit(ifit):
        # Running test fits
            fitCommand = f"python AmplitudeModel/runConfigSimFit.py --tupleDir={tuplesDir} --logDir={logsDir} --saveLabel=simFit-fit-{ifit} --toysPathUC={fitDataPathUC} --toysPathQC={fitDataPathQC} --resIndFile={modelFile} --nToys=1"
            os.system(fitCommand)
        
        dataFitArgmap = [[i] for i in range(nfits)]
        dataFitPool = Pool(8)
        results = dataFitPool.starmap(runDataFit, dataFitArgmap)
        
        # Extracting best NLL
        bestFitFile, configNLL = getBestNLL(glob(f"{tuplesDir}/simFit-fit-*-UC-fitHist.root")) # NLL from fit to data
        configNdof = (len(modelResInd)-1)*2
        
        
        # Monte-Carlo method to determine distribution of likelihood ratio test statistic
        
        # Generating toy with configuration
        toyPathNLL_UC = f"{baselineTuplesDir}/baseline-deltaNLLtoy-UC.root"
        toyPathNLL_QC = f"{baselineTuplesDir}/baseline-deltaNLLtoy-QC.root"
        if modelKey == 'baseline':
            logPathUC = f"{logsDir}/{modelKey}-deltaNLLtoy-UC.log"
            logPathQC = f"{logsDir}/{modelKey}-deltaNLLtoy-QC.log"
            os.system(f"./bin/genFromFit {bestFitFile} {toyPathNLL_UC} {nevtsToysUC} {0} {ntoys} {0} {modelFile} > {logPathUC} 2>&1")
            os.system(f"./bin/genFromFit {bestFitFile} {toyPathNLL_QC} {nevtsToysQC} {0} {ntoys} {1} {modelFile} > {logPathQC} 2>&1") 
        
        # Fit model to toy
        print("Line 115:", tuplesDir)
        def runToyFit(i):
            fitPathNLL = f"{tuplesDir}/{modelKey}-deltaNLLfit-fitHist-{i}.root"
            logPath = f"{logsDir}/{modelKey}-deltaNLLfit-fitHist-{i}.log"
            fitCommand = f"python AmplitudeModel/runConfigSimFit.py --tupleDir={tuplesDir} --logDir={logsDir} --saveLabel={modelKey}-deltaNLLfit-fit-{i} --toysPathUC={toyPathNLL_UC} --toysPathQC={toyPathNLL_QC} --resIndFile={modelFile} --nToys={ntoys}"
            os.system(fitCommand)
        
        toyFitArgmap = [[i] for i in range(nfits)]
        toyFitPool = Pool(8)
        results = toyFitPool.starmap(runToyFit, toyFitArgmap)
        
        # Collating fit results from multiple refits
        print("Line 127:",glob(f"{tuplesDir}/{modelKey}-deltaNLLfit-fit-*-UC-fitHist.root"))
        toyFitResults = uproot.concatenate(glob(f"{tuplesDir}/{modelKey}-deltaNLLfit-fit-*-UC-fitHist.root"), library='pd')
        toyFitResultsCsv = f"{resultsDir}/{modelKey}-toyFitResults.csv"
        bestToyFitDFList = []
        
        for i in range(ntoys):
            exptDf = toyFitResults[toyFitResults["iExpt"] == i]
            minNLLDf = exptDf[exptDf.NLL == exptDf.NLL.min()]
            if (len(minNLLDf.index) > 1):
                minNLLDf = minNLLDf.sample(1)
            bestToyFitDFList.append(minNLLDf)

        bestFitResults = pd.concat(bestToyFitDFList, ignore_index=True)
        
        bestFitResults.to_csv(toyFitResultsCsv)
        
        # Calculating change in NLL
        if modelKey != "baseline":
            # Calculating NLL ratio distribution from toys
            baselineNLLfits = pd.read_csv(f"{baselineResultsDir}/baseline-toyFitResults.csv")
            baselineNLLfits.set_index(['iExpt'])
            
            configNLLfits = pd.read_csv(f"{resultsDir}/{modelKey}-toyFitResults.csv")
            configNLLfits.set_index(['iExpt'])

            baselineNLLfits.set_index(['iExpt'])
            configNLLfits.set_index(['iExpt'])
            deltaNLLdataframe = baselineNLLfits.copy()
            deltaNLLdataframe["deltaNLL"] = 2*(configNLLfits['NLL'] - baselineNLLfits['NLL'])
            deltaNLLdataframe.to_csv(f"{resultsDir}/deltaNLL.csv", columns = ['deltaNLL'])

            # Calculating NLL ratio
            deltaNLL = (configNLL - baselineNLL)
            deltaNdof = configNdof - baselineNdof
            #pval = scipy.stats.chi2.sf(-2*deltaNLL, df=deltaNdof)
            pval = np.sum(np.array(deltaNLLdataframe['deltaNLL'] > deltaNLL))/len(list(deltaNLLdataframe['deltaNLL'])) # p-value from Monte-Carlo
            fileLines.append(f"Change in NLL for {modelKey}: {deltaNLL} \n")
            
            # Fitting Gaussian to test statistic distribution
            deltaNLLdist = np.array(list(deltaNLLdataframe['deltaNLL']))
            #chi2nsamples = 100000
            #weights = [ntoys/chi2nsamples]*chi2nsamples
            #chisqSamples = np.random.chisquare(df=2, size=chi2nsamples)
            
            
            #print((deltaNLLdist))
            """
            obs = zfit.Space('deltaNLL', limits=(3*min(deltaNLLdist), 0))
            #obs = zfit.Space('deltaNLL', limits=(0, 3*max(deltaNLLdist)))
            paramData = zfit.Data.from_pandas(deltaNLLdataframe, obs=obs)
            mu = zfit.Parameter(modelKey + "_mu", np.mean(deltaNLLdist), 3*min(deltaNLLdist), 0)
            #mu = zfit.Parameter(modelKey + "_mu", np.mean(deltaNLLdist), 0, 3*max(deltaNLLdist))
            sigma = zfit.Parameter(modelKey + "_sigma", np.std(deltaNLLdist), 0, 5*np.std(deltaNLLdist))
            gauss = zfit.pdf.Gauss(obs=obs, mu=mu, sigma=sigma)
            #fitNdof = zfit.Parameter(modelKey + "_ndof", 2, 0, 1000)
            #chisqDist = zfit.pdf.ChiSquared(fitNdof, obs)
            
            pullsNLL = zfit.loss.UnbinnedNLL(model=gauss, data=paramData)
            #pullsNLL = zfit.loss.UnbinnedNLL(model=chisqDist, data=paramData)
            minimizer = zfit.minimize.Minuit()
            pullsFitResult = minimizer.minimize(pullsNLL)
            pullsFitErr = pullsFitResult.hesse()
            
            
            #pval = scipy.stats.chi2.sf(deltaNLL, 2)
            print(f"Ndof: {pullsFitResult.params[fitNdof]['value']}")
            pval = scipy.stats.chi2.sf(deltaNLL, pullsFitResult.params[fitNdof]['value'])
            
            pval = scipy.stats.chi2.sf(deltaNLL, 2)
            configSignificance = scipy.stats.norm.isf(pval)
            """
            mu = np.mean(deltaNLLdist)
            sigma = np.std(deltaNLLdist)
            textstr = '\n'.join((
                #r'$\mu=%.2f\pm%.2f$' % (pullsFitResult.params[mu]['value'], pullsFitErr[mu]['error']),
                #r'$\sigma=%.2f\pm%.2f$' % (pullsFitResult.params[sigma]['value'], pullsFitErr[sigma]['error']),
                r'$\mu=%.2f$' % (mu),
                r'$\sigma=%.2f$' % (sigma),
                r'$t_{\text{data}}=%.2f$' % (deltaNLL),
                #r'pval=%.2e' % (pval),
                #r'Significance=%.2f' % (configSignificance) 
                #r'$\mu - t_{\text{data}}=%.1f \sigma$' % ((pullsFitResult.params[mu]['value'] - deltaNLL)/pullsFitResult.params[sigma]['value']),
                r'$\mu - t_{\text{data}}=%.1f \sigma$' % ((mu - deltaNLL)/sigma),
                ))
            
            # Making plots of test statistic
            mplhep.style.use("LHCb2")
            fig = plt.figure()
            ax = fig.add_subplot(111)
            plt.hist(deltaNLLdist, bins=50, label=r'$t_{\text{toys}}$')
            #plt.hist(chisqSamples, bins=50, histtype='step', color='r', zorder=5, weights=weights)
            plt.text(0.25, 0.70, textstr, fontsize=20, transform=ax.transAxes)
            plt.axvline(deltaNLL, c='red')
            plt.xlabel(r'$\Delta(-2\log{(\mathrm{\mathcal{L})}})$')
            plt.ylabel("Num. of toys")
            plt.savefig(f"{resultsDir}/deltaNLL_distribution.pdf")
            plt.close()
            print(f"delta NLL distribution saved to: {resultsDir}/deltaNLL_distribution.pdf")
            
            
        else:
            baselineNLL = configNLL
            baselineNdof = configNdof

    
        # Calculating binned chi2
        #os.system(f"python FitQuality/runBinnedChi2.py {fitDataPath} {fitDataPath} {bestFitFile} {resultsDir}/chi2- {modelFile}")
    saveFile = open(resultSavePath, "w")
    saveFile.write("Tested configurations: \n")
    for key, item in modelConfigurations.items():
        saveFile.write(f"   {key} : {item} \n")
    saveFile.write("\n")
    for line in fileLines:
        saveFile.write(line)
    saveFile.close()
    print(f"Toy study result saved to: {resultSavePath}")