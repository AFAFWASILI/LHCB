#include <cstdlib>
#include <iostream>
#include <vector>
#include <cstring>

#include "LauDaughters.hh"
#include "LauEffModel.hh"
#include "LauIsobarDynamics.hh"
#include "LauMagPhaseCoeffSet.hh"
#include "LauSimpleFitModel.hh"
#include "LauAbsCoeffSet.hh"
#include "LauVetoes.hh"
#include "TFile.h"
#include "TString.h"
#include "TTree.h"
#include "TROOT.h"
#include "resonInfo.h"
#include "buildResonanceModel.h"
#include "modelUtilities.h"

void usage(std::ostream &out, const TString &progName) {
    out << "Usage:\n";
    out << progName << " [fitSamplePath] [nominalFitPath] [fitOutputPathPrefix] [ntoys] [correlated=0]\n"
        << std::endl;
}

int main(int argc, char **argv) {
    /* #region CLI Argument handling*/
    if (argc < 5) {
        usage(std::cerr, argv[0]);
        return EXIT_FAILURE;
    }

    Bool_t isToy(kTRUE);

    // Configuring file names
    TString fitSamplePath;
    TString nominalFitPath; // Path to fit results used to generate sample; needed in order to save the correct generator (true) value
    TString fitOutputPathPrefix;  // If file path prefix is "XXX/YYY/ZZZ/gen-", then file will be saved as "XXX/YYY/ZZZ/gen-fitHist.root" (fitHist defined in CLI handling section)
    TString genOutputPathPrefix;
    TString genDataSavePath;
    TString histFilePath;
    TString tableFilePath;
    TString hostname;
    UInt_t port;
    TString dataFile;  // Output containing generated events if running in "gen" mode, input w/data in "fit" mode
    TString treeName = "DecayTree";


    // Parsing arguments
    fitSamplePath = argv[1];
    nominalFitPath = argv[2];
    fitOutputPathPrefix = argv[3];
    int ntoys = atoi(argv[4]);
    bool correlated = false;
    if (atoi(argv[5]) == 1) {
        correlated = true;
    }


    // Setting I/O paths
    dataFile = fitSamplePath;
    histFilePath = fitOutputPathPrefix + "fitHist.root";
    tableFilePath = fitOutputPathPrefix + "fitResults.tex";


    // Setting nEventsData to number of events in tree
    TFile *inputFile = new TFile(dataFile);  // Currently set up to
    TTree *inputTree = (TTree *)inputFile->Get(treeName);
    UInt_t nEventsData = inputTree->GetEntries();
    Bool_t squareDP = kFALSE;  // PN: I don't think we need squareDP for this toy study, well at least not the first stage.....
    Bool_t fixMass = kTRUE;    // Fix mass of resonances in fit
    Bool_t fixWidth = kTRUE;   // Fix width of resonances in fit


    /* #region Defining decay model */

    LauDaughters *daughters = new LauDaughters("B+", "D0_bar", "D0", "K+", squareDP);

    LauVetoes *vetoes = new LauVetoes();
    LauEffModel *effModel = new LauEffModel(daughters, vetoes);  // Efficiency model

    // Defining isobar decay model
    LauIsobarDynamics *sigModel = new LauIsobarDynamics(daughters, effModel);
    sigModel->setNarrowResonanceThreshold(0.03);

    std::vector<resonInfo> resonanceModel = readFitResults(nominalFitPath, fitResonanceList);

    std::vector<LauAbsCoeffSet*> uncorrelatedCoeffset = addUncorrelatedResonances(sigModel, resonanceModel, fixMass, fixWidth); // Adding resonances to isobar model
    std::vector<LauAbsCoeffSet*> coeffset;

    if (correlated) {
        std::vector<double> ampFactors = computeAmpFactors(fitResonanceList);
        int n = ampFactors.size();

        for (int i = 0; i < n; i++) {
            LauAbsCoeffSet* tempParam = uncorrelatedCoeffset[i];
            int resonanceID = fitResonanceList[i];
            ampFactors[i] = 1.;

            // Multiplying amplitude by factor
            for (auto param : tempParam->getParameters()){
                if (param->name() == "A") {
                    param->value(param->value()*ampFactors[i]);
                    param->genValue(param->value()); // Setting generator (true) value so param_true in fit output is correct
                }
            }
            
            if (std::find(suppressedResonanceList.begin(), suppressedResonanceList.end(), resonanceID) != suppressedResonanceList.end()) { // Check if resonance is suppressed
                for (auto param : tempParam->getParameters()){
                    param->initValue(param->value()); // Fixing initial value so param not randomised at start of fit
                }
                // Fixing amplitude and phase
                tempParam->fixParameter("A");
                tempParam->fixParameter("Delta");
            }

            coeffset.push_back(tempParam);

        }
    } else {
        coeffset = uncorrelatedCoeffset;
    }

    sigModel->setASqMaxValue(9.0);
    LauSimpleFitModel *fitModel = new LauSimpleFitModel(sigModel);

    for (std::vector<LauAbsCoeffSet *>::iterator iter = coeffset.begin(); iter != coeffset.end(); ++iter) {
        fitModel->setAmpCoeffSet(*iter);
    }
    // LauParameter* nSigEvents = new LauParameter("signalEvents",nEventsData,-1000.0,100000.0,kTRUE);
    LauParameter *nSigEvents = new LauParameter("signalEvents", nEventsData, -1000.0, nEventsData, kTRUE);

    // Configuring the fit
    fitModel->twoStageFit(kTRUE);
    fitModel->setNSigEvents(nSigEvents);
    // fitModel->setNExpts( 1, 0 , kFALSE); // (kTRUE if you want generation within gaussian mean, see inc/LauFitObject.hh)
    // fitModel->setNExpts( nExpt, firstExpt, isToy );
    fitModel->setNExpts(ntoys, 0, kFALSE);
    fitModel->useAsymmFitErrors(kFALSE);
    fitModel->useRandomInitFitPars(kTRUE);
    fitModel->doPoissonSmearing(kTRUE);
    fitModel->doEMLFit(false);

    // Executing generation/fit
    fitModel->run("fit", dataFile, treeName, histFilePath, tableFilePath);

    return EXIT_SUCCESS;
}
