import numpy as np
import matplotlib.pyplot as plt
import mplhep
import pandas as pd
import awkward as ak
import uproot
import os
import shutil
import sys
import glob
import re
import zfit
from warnings import simplefilter
from glob import glob
from multiprocessing import Pool
from uncertainties import ufloat
from scipy.stats import norm

resonanceNames = {
    "0" : "chi_c2_2P",
    "1" : "chi_c0_2P",
    "2" : "Ds*+_1_2700",
    "3" : "psi_3770",
    "4" : "psi_4040",
    "5" : "psi_4160",
    "6" : "psi_4415",
    "7" : "Belle_NR"
}


resonanceLatex = {
    "0" : r'$\chi_{c2}(2P)$',
    "1" : r'$\chi_{c0}(2P)$',
    "2" : r'$D_{s1}^{*+}(2700)$',
    "3" : r'$\psi(3770)$',
    "4" : r'$\psi(4040)$',
    "5" : r'$\psi(4160)$',
    "6" : r'$\psi(4415)$',
    "7" : r'Non-res'
}

def parseIndVector(filepath, vecName):
    # Reads a vector containing resonance indices from .cpp source file
    cppFile = open(filepath, mode='r')
    lines = cppFile.readlines()
    for line in lines:
        targetLine = f"std::vector<int> {vecName}{{"
        if targetLine in line:
            if line[:2] != '//':
                parsedLine = [i.split('}')[0] for i in line.split('{')[1:]][0]
                parsedLine = parsedLine.replace(' ', '')
                if ',' in parsedLine:
                    parsedLine = [str(elem) for elem in parsedLine.split(',')]
                    return parsedLine
                else:
                    return [parsedLine]

# Setting up lists of floated, fixed and suppressed resonances by parsing amplitude model file
fitResIndices = parseIndVector("b2d0d0bk_model/buildResonanceModel.cpp", "fitResonanceList")
fixedResIndices = parseIndVector("b2d0d0bk_model/buildResonanceModel.cpp", "fixedResList")
suppressedResIndices = parseIndVector("b2d0d0bk_model/buildResonanceModel.cpp", "suppressedResonanceList")
fixedResonances = [i for i in range(len(fitResIndices)) if str(fitResIndices[i]) in fixedResIndices] # Indices of fixed resonances
suppressedResonances = [i for i in range(len(fitResIndices)) if str(fitResIndices[i] in suppressedResIndices)]

# Writing list of resonances into .txt file
resIndFile = open("output/temp/fitModelIndPath.txt", 'w')
for i in fitResIndices:
    resIndFile.write((str(i) + '\n'))
resIndFile.close()

def plotPulls(windowDF, nResons, savepath, plotGaus = True):
    distFitResults = {}
    
    fig, axs = None, None
    fig2, axs2 = None, None
    subplots = []
    
    if (nResons-1) <= 4:
        fig, axs = plt.subplots(nResons-1, 2, figsize=(24, 8*(nResons-1)), layout='constrained')
        for i in range(0, nResons, 1):
            resName = resonanceNames[str(i)]
            resAmpName = f"A{i}_A"
            resPhaseName = f"A{i}_Delta"
            resParamList = [resAmpName, resPhaseName]

            paramSubplots = []
            for j in range(len(resParamList)):
                if (i not in fixedResonances):
                    paramSubplots.append(axs[i-1, j])
            if len(paramSubplots) != 0:
                subplots.append(paramSubplots)
    else:
        fig, axs = plt.subplots(4, 2, figsize=(24, 32), layout='constrained')
        fig2, axs2 = plt.subplots(nResons-5, 2, figsize=(24, 8*(nResons-5)), layout='constrained')
        for i in range(0, nResons, 1):
            resName = resonanceNames[str(i)]
            resAmpName = f"A{i}_A"
            resPhaseName = f"A{i}_Delta"
            resParamList = [resAmpName, resPhaseName]
            paramSubplots = []
            for j in range(len(axs)):
                subplots.append(axs[j])
            
            for j in range(len(axs2)):
                subplots.append(axs2[j])  
                
    resPlotCounter = 0
    
    for i in range(0, nResons, 1):
        if (i not in fixedResonances):
            resName = resonanceNames[str(i)]
            resAmpName = f"A{i}_A"
            resPhaseName = f"A{i}_Delta"
            resParamList = [resAmpName, resPhaseName]

            for j in range(len(resParamList)):
                #currentSubplot = axs[i-1, j]
                currentSubplot = subplots[resPlotCounter][j]
                #pullDF = (windowDF[resParamList[j]] - windowDF[resParamList[j] + "_True"])/windowDF[resParamList[j]+"_Error"]
                pullDF = windowDF[resParamList[j]+"_Pull"]
                binHeights, binEdges, patches = currentSubplot.hist(pullDF, bins=50, histtype='step')
                currentSubplot.set_xlabel(f"{resName} {resParamList[j]}", loc='center')
                #currentSubplot.ticklabel_format(axis='x', style='sci', scilimits=(0,0), useOffset=False)
                
                # Performing fit to data distribution
                obs = zfit.Space(resParamList[j] + "_Pull", limits=(-10, 10))
                paramData = zfit.Data.from_pandas(pullDF, obs=obs)
                
                mu = zfit.Parameter(resParamList[j] + '_Pull_mu', 0.1, -8, 8)
                sigma = zfit.Parameter(resParamList[j] + '_Pull_sigma', 1, -5, 5)
                gauss = zfit.pdf.Gauss(obs=obs, mu=mu, sigma=sigma)
                
                pullsNLL = zfit.loss.UnbinnedNLL(model=gauss, data=paramData)
                minimizer = zfit.minimize.Minuit()
                pullsFitResult = minimizer.minimize(pullsNLL)
                pullsFitErr = pullsFitResult.hesse()
                
                # Plotting fit
                xmin, xmax = currentSubplot.get_xlim()
                x = np.linspace(xmin, xmax, 100)
                binWidth = binEdges[1] - binEdges[0]
                integral = sum(binWidth*binHeights)
                y = integral*gauss.pdf(x)
                if plotGaus:
                    currentSubplot.plot(x, y)
                    
                # Printing results from fit
                textstr = '\n'.join((
                    r'$\mu=%.5f\pm%.5f$' % (pullsFitResult.params[mu]['value'], pullsFitErr[mu]['error']),
                    r'$\sigma=%.5f\pm%.5f$' % (pullsFitResult.params[sigma]['value'], pullsFitErr[sigma]['error'])))
                currentSubplot.text(0.08, 0.80, textstr, fontsize=20, transform=currentSubplot.transAxes)
                # Saving results from fit to dictionary
                distFitResults[resParamList[j] + "_mu"] = [pullsFitResult.params[mu]['value'], pullsFitErr[mu]['error']]
                distFitResults[resParamList[j] + "_sigma"] = [pullsFitResult.params[sigma]['value'], pullsFitErr[sigma]['error']]
                """
                # Saving results from fit to dictionary (Placeholder)
                distFitResults[resParamList[j] + "_mu"] = [pullsFitResult.params[mu]['value'], 0]
                distFitResults[resParamList[j] + "_sigma"] = [pullsFitResult.params[sigma]['value'], 0]
                """
            resPlotCounter += 1
        
    fig.savefig(savepath)
    if fig2 != None:
        savepath2 = savepath[:-4] + "-2.pdf"
        fig2.savefig(savepath2)
        
    return distFitResults
  
def getFitFracErr(windowDF):
    distFitResults = {}
    for i in range(0, 7, 1):
        resName = resonanceNames[str(i)]
        fitFracName = f"A{i}Sq_FitFrac"
        fitFracDF = windowDF[fitFracName]
            
        # Performing fit to distribution in toy ensemble
        obs = zfit.Space(fitFracName, limits=(0, 1))
        paramData = zfit.Data.from_pandas(fitFracDF, obs=obs)
        
        mu = zfit.Parameter(fitFracName + '_mu', 0, -5, 5)
        sigma = zfit.Parameter(fitFracName + '_sigma', 1, -3, 3)
        gauss = zfit.pdf.Gauss(obs=obs, mu=mu, sigma=sigma)
        
        pullsNLL = zfit.loss.UnbinnedNLL(model=gauss, data=paramData)
        minimizer = zfit.minimize.Minuit()
        pullsFitResult = minimizer.minimize(pullsNLL)
        pullsFitErr = pullsFitResult.hesse()
        
        # Saving results from fit to dictionary
        distFitResults[fitFracName + "_mu"] = [pullsFitResult.params[mu]['value'], pullsFitErr[mu]['error']]
        distFitResults[fitFracName + "_sigma"] = [pullsFitResult.params[sigma]['value'], pullsFitErr[sigma]['error']]
        
    return distFitResults

def plotParams(windowDF, nResons, savepath, plotGaus = True, plotTruth = True):
    distFitResults = {}
    
    fig, axs = None, None
    fig2, axs2 = None, None
    subplots = []
    
    if (nResons-1) <= 4:
        fig, axs = plt.subplots(nResons, 3, figsize=(24, 8*(nResons-1)), layout='constrained')
        for i in range(0, nResons, 1):
            resName = resonanceNames[str(i)]
            resAmpName = f"A{i}_A"
            resPhaseName = f"A{i}_Delta"
            resFitFracName = f"A{i}Sq_FitFrac"
            resParamList = [resAmpName, resPhaseName, resFitFracName]

            paramSubplots = []
            for j in range(len(resParamList)):
                if (i not in fixedResonances):
                    paramSubplots.append(axs[i-1, j])
            if len(paramSubplots) != 0:
                subplots.append(paramSubplots)
    else:
        fig, axs = plt.subplots(4, 3, figsize=(24, 32), layout='constrained')
        fig2, axs2 = plt.subplots(nResons-4, 3, figsize=(24, 8*(nResons-4)), layout='constrained')
        for i in range(0, nResons, 1):
            resName = resonanceNames[str(i)]
            resAmpName = f"A{i}_A"
            resPhaseName = f"A{i}_Delta"
            resFitFracName = f"A{i}Sq_FitFrac"
            resParamList = [resAmpName, resPhaseName, resFitFracName]
            paramSubplots = []
            if (i <= 3):
                for j in range(len(resParamList)):
                    paramSubplots.append(axs[i, j])
            else:
                for j in range(len(resParamList)):
                    paramSubplots.append(axs2[i-4, j])
            if len(paramSubplots) != 0:
                subplots.append(paramSubplots)


    for i in range(0, nResons, 1):
        resName = resonanceNames[str(i)]
        resAmpName = f"A{i}_A"
        resPhaseName = f"A{i}_Delta"
        resFitFracName = f"A{i}Sq_FitFrac"
        resParamList = [resAmpName, resPhaseName, resFitFracName]
        
        for j in range(len(resParamList)):
            #currentSubplot = ax[i, j]
            currentSubplot = subplots[i][j]
            currentParam = resParamList[j]
            paramDF = windowDF[currentParam]
            paramTruthVal = windowDF[currentParam + "_True"][0]
            
            # Plotting histogram
            binHeights, binEdges, patches = currentSubplot.hist(paramDF, bins=50, histtype='step')
            currentSubplot.set_xlabel(f"{resName} {currentParam}", loc='center')

            # Perform fit to distribution if resonance is not fixed or when dealing with fit fraction
            if (not(i in fixedResonances) or (j == 2)):
                # Performing fit to data distribution
                obs = zfit.Space(currentParam, limits=(-6, 6))
                paramData = zfit.Data.from_pandas(paramDF, obs=obs)
                paramValList = list(paramDF)
                
                mu = zfit.Parameter(currentParam + '_mu', np.mean(paramValList), -3*abs(min(paramValList)), 3*abs(max(paramValList)))
                sigma = zfit.Parameter(currentParam + '_sigma', np.std(paramValList), -5*np.std(paramValList), 5*np.std(paramValList))
                gauss = zfit.pdf.Gauss(obs=obs, mu=mu, sigma=sigma)
                
                paramNLL = zfit.loss.UnbinnedNLL(model=gauss, data=paramData)
                minimizer = zfit.minimize.Minuit()
                
                paramFitResults = minimizer.minimize(paramNLL)
                paramFitErrs = paramFitResults.hesse()

                distFitResults[currentParam + "_mu"] = [paramFitResults.params[mu]['value'], paramFitErrs[mu]['error']]
                distFitResults[currentParam + "_sigma"] = [paramFitResults.params[sigma]['value'], paramFitErrs[sigma]['error']]
                
                # Printing results from fit
                textstr = '\n'.join((
                    r'$\mu=%.4f\pm%.4f$' % (paramFitResults.params[mu]['value'], paramFitErrs[mu]['error']),
                    r'$\sigma=%.4f\pm%.4f$' % (paramFitResults.params[sigma]['value'], paramFitErrs[sigma]['error']),
                    r'True val=%.4f' % (paramTruthVal)
                    ))
                currentSubplot.text(0.08, 0.80, textstr, fontsize=20, transform=currentSubplot.transAxes)
                
                # Plotting fit
                xmin, xmax = currentSubplot.get_xlim()
                x = np.linspace(xmin, xmax, 100)
                binWidth = binEdges[1] - binEdges[0]
                integral = sum(binWidth*binHeights)
                y = integral*gauss.pdf(x)
                if plotGaus:
                    currentSubplot.plot(x, y)
                
                if plotTruth:
                    currentSubplot.axvline(paramTruthVal, c='r')
    
    fig.savefig(savepath)
    if fig2 != None:
        savepath2 = savepath[:-4] + "-2.pdf"
        fig2.savefig(savepath2)

    return distFitResults
                
def writeTableLine(arr):
    linestr = "";
    for i in range(len(arr)):
        arrItem = arr[i]
        if type(arrItem) != str:
            arrItem = "{:.4f}".format(arrItem)
            if "+/-" in arrItem:
                arrItem = arrItem.replace("+/-", r' \pm ')
            arrItem = f"${arrItem}$"
        if (i != len(arr)-1):
            linestr += arrItem + " & "
        else:
            linestr += arrItem + " \\\\"
    return linestr

def correctFitParam(nominalFitVal, bias, pullWidth):
    corrCentralVal = nominalFitVal - bias
    corrParamErr = nominalFitVal.std_dev * pullWidth
    return corrCentralVal, corrParamErr

def writeParamLine(resonLatex: str, paramLabel: str, paramName: str, pullsDistFit: dict, nominalDF: pd.DataFrame, printTruth: bool):
    def getNominalVal(valname):
        return nominalDF[valname][0]
    paramNominalVal = ufloat(getNominalVal(paramName), getNominalVal(paramName + "_Error"))
    paramBias = ufloat(pullsDistFit[paramName + "_mu"][0], pullsDistFit[paramName + "_mu"][1])*paramNominalVal.nominal_value
    paramPullWidth = ufloat(pullsDistFit[paramName + "_sigma"][0], pullsDistFit[paramName + "_sigma"][1])
    paramCorr, paramErrCorr = correctFitParam(paramNominalVal, paramBias, paramPullWidth)
    
    totalErr = np.sqrt(paramCorr.std_dev**2 + paramErrCorr.nominal_value**2)
    paramTableLine = [resonLatex, paramLabel, paramNominalVal.nominal_value, paramNominalVal.std_dev, paramBias, paramPullWidth, paramCorr.nominal_value, paramErrCorr.nominal_value, totalErr]
    if printTruth:
        paramTableLine.append(getNominalVal(paramName + "_True"))
    return paramTableLine

if __name__ == "__main__":
    
    # Configuring toy ensemble parameters
    nToys = 20 # Number of toys
    nEvtsToy = 5000 # Number of events per toy
    nFitsToy = 5 # Number of repeated fits per toy
    runEnsembleFit = True # Whether to generate and fit on toy ensemble or not
    correlated = False
    
    # Simultaneous fit configuration
    simFit = False
    simFitUCnevts = 1000
    simFitQCnevts = 1000
    
    # Configuring paths - Input files
    nominalFitPath = "output/FittingTests/UC_Only/Tuples/UC-5000evts-fitHist-4.root"
    #nominalFitPath = "output/FittingTests/QC_Only/Tuples/QC-5000evts-fitHist-18.root"
    nominalSimFitUCPath = "output/FittingTests/SimFit/UC/Tuples/UC1000evts-QC1000evts-fit8-fitHist.root"
    
    # Configuring paths - Output files
    subdir = "UC/"
    if correlated:
        subdir = "QC/"
    elif simFit:
        subdir = "SimFit/"
    refitResultsCsv = f"output/FitBias/{subdir}toyFitResults.csv"
    tableSavePath = f"output/FitBias/{subdir}biasCorrections.tex"
    correctedParamsPath = f"output/FitBias/{subdir}correctedFitParams.root"
    ensembleFitResultsDir = f"output/FitBias/{subdir}Tuples"
    ensembleFitLogsDir = f"output/FitBias/{subdir}Logs/"
    ensembleToysPath = f"output/FitBias/{subdir}Tuples/biasCorrectionToy.root"    
    ensembleToysPathUC = f"output/FitBias/{subdir}Tuples/simFit-biasToyUC.root"
    ensembleToysPathQC = f"output/FitBias/{subdir}Tuples/simFit-biasToysQC.root"

    
    if correlated:
        fixedResonances = fixedResonances + suppressedResonances
    
    if simFit:
        nominalFitPath = nominalSimFitUCPath
    
    nominalDF = uproot.open(nominalFitPath + ":fitResults", library='pd').arrays()
    nominalDF = ak.to_dataframe(nominalDF)

    # Suppressing Pandas warnings
    simplefilter(action="ignore", category=pd.errors.PerformanceWarning)
    # Generating and fitting to toy ensembles
    if runEnsembleFit:
        paramsList = []
        paramsList.append([f"A{i}_A" for i in range(0, 8)])
        paramsList.append([f"A{i}_Delta" for i in range(0, 8)])
        
        # Generating toy - Currently only supports uncorrelated sample fit
        if simFit:
            os.system(f"./bin/genFromFit {nominalFitPath} {ensembleToysPathQC} {simFitQCnevts} 0 {nToys} 1 output/temp/fitModelIndPath.txt > {ensembleFitLogsDir}QC-ensembleGenLog.log 2>&1")
            os.system(f"./bin/genFromFit {nominalFitPath} {ensembleToysPathUC} {simFitUCnevts} 0 {nToys} 0 output/temp/fitModelIndPath.txt > {ensembleFitLogsDir}UC-ensembleGenLog.log 2>&1")
        else:
            os.system(f"./bin/genFromFit {nominalFitPath} {ensembleToysPath} {nEvtsToy} 0 {nToys} 0 output/temp/fitModelIndPath.txt > {ensembleFitLogsDir}/genLog.log 2>&1")
        
        # Defining fit function for multiprocessing
        def runRefit(i):
            print(f"Running toy refit {i}")
            if simFit:
                os.system(f"python 4_FitBiasCorrection/runBiasCorrectionSimFit.py --tupleDir={ensembleFitResultsDir} --logDir={ensembleFitLogsDir} --saveLabel=toyRefit-simFit-{i} --toysPathUC={ensembleToysPathUC} --toysPathQC={ensembleToysPathQC} --nominalFitPath={nominalSimFitUCPath} --ntoys={nToys}")
            else:
                biasFitSavePath = ensembleFitResultsDir + f"/toyRefit-{i}-"
                os.system(f"./bin/biasCorrectionFit {ensembleToysPath} {nominalFitPath} {biasFitSavePath} {nToys} {int(correlated)} > {ensembleFitLogsDir}/ensembleFitLog-{i}.log 2>&1")

        # Performing repeated fits to toys
        argmap = [[i] for i in range(nFitsToy)]
        multiprocessingPool = Pool(6)
        results = multiprocessingPool.starmap(runRefit, argmap)
        
        fitResultsList = []
        if simFit:
            fitResultsList = glob(f"{ensembleFitResultsDir}/*UC-fitHist.root")
        else:
            fitResultsList = glob(f"{ensembleFitResultsDir}/*fitHist.root")
        
        print("Finished fitting and saving results, aggregating results to .csv")
        
        # Reading in toy refit results
        nominalFitDf = uproot.open(nominalFitPath+":fitResults", library='pd')
        toyRefitResults = uproot.concatenate(fitResultsList, library='pd')
        bestFitDFList = []
        
        for i in range(nToys):
            exptDf = toyRefitResults[toyRefitResults["iExpt"] == i]
            minNLLDf = exptDf[exptDf.NLL == exptDf.NLL.min()]
            if (len(minNLLDf.index) > 1):
                minNLLDf = minNLLDf.sample(1)
            bestFitDFList.append(minNLLDf)

        bestFitResults = pd.concat(bestFitDFList, ignore_index=True)
        
        bestFitResults.to_csv(refitResultsCsv)
    
    # Reading in results from ensemble fit
    refitDF = pd.read_csv(refitResultsCsv)
    
    # Pulls for full window
    nResons = len(fitResIndices)
    
    if correlated:
        nResons = nResons - 4
    mplhep.style.use("LHCb2")
    #fig, axs = plt.subplots(nResons-1, 2, figsize=(24, 8*(nResons-1)), layout='constrained')
    pullsDistFit = plotPulls(refitDF, nResons, f"output/FitBias/{subdir}toyEnsemble-pullsDistribution.pdf")
    #paramsDistFit = getFitFracErr(refitDF)
    #plt.savefig(f"output/FitBias/{subdir}toyEnsemble-pullsDistribution.pdf")
    #plt.close()
    
    # Plotting toy ensemble parameter distributions
    #fig2, axs2 = plt.subplots(nResons, 3, figsize = (24, 8*nResons), layout='constrained')
    paramsDistFit = plotParams(refitDF, nResons, f"output/FitBias/{subdir}toyEnsemble-paramDistribution.pdf", True, True)
    #plt.savefig(f"output/FitBias/{subdir}toyEnsemble-paramDistribution.pdf")
    #plt.close()
    
    # Creating LaTeX table for fit results
    printTruth = True
    
    correctedFitParams = {}
    with open(tableSavePath, "w") as tableFile:
        colNames = ["Parameter", "", "Central value (raw)", "Stat. (raw)", "Bias (From pulls)", "Pull width", "Central value (Corrected)", "Stat. (Corrected)", "Stat. + Syst."]
        if printTruth:
            colNames.append("True val.")
        
        initLine = "\\begin{tabular}{"
        for i in range(len(colNames)-1):
            initLine += "c "
        initLine += "c}"
        tableFile.write(initLine + '\n')
        tableFile.write(r'    \hline' + '\n')
        tableFile.write(r'    \hline' + '\n')
        tableFile.write(r'    ' + writeTableLine(colNames) + '\n')
        tableFile.write(r'    \hline' + '\n')
        tableFile.write(r'    \hline' + '\n')

        for i in range(0, nResons, 1):
            resonLatex = resonanceLatex[str(i)]
            ampName = f"A{i}_A"
            phaseName = f"A{i}_Delta"
            fitFracName = f"A{i}Sq_FitFrac"
            if (i not in fixedResonances):
                # Writing lines for magnitude and phase
                ampTableLine = writeParamLine(resonLatex, "Magnitude", ampName, pullsDistFit, nominalDF, printTruth)
                phaseTableLine = writeParamLine("", "Phase (rad)", phaseName, pullsDistFit, nominalDF, printTruth)
            else:
                ampTableLine = ["", "Magnitude", 1, "", "", "", 1, "", ""]
                phaseTableLine = ["", "Magnitude", 0, "", "", "", 0, "", ""]
                if printTruth:
                    ampTableLine.append(1)
                    phaseTableLine.append(0)
                
            # Performing calculations for fit fraction
            fitFracCV = nominalDF[fitFracName][0] # Central value (value from nominal fit)
            fitFracBias = ufloat(paramsDistFit[fitFracName + "_mu"][0], paramsDistFit[fitFracName + "_mu"][1]) - nominalDF[fitFracName + "_True"][0] # Calculating offset wrt value used to generate toys (i.e fit value of nominal fit)
            fitFracCorrected = fitFracCV - fitFracBias
            fitFracErr = paramsDistFit[fitFracName + "_sigma"][0] # Fit frac error from width of distribution in toy emsemble
            tableFile.write(r'    ' + writeTableLine(ampTableLine) + '\n')
            tableFile.write(r'    ' + writeTableLine(phaseTableLine) + '\n')

            
            fitFracTableLine = ["", "Fit fraction", fitFracCV, "", fitFracBias, "", fitFracCorrected.nominal_value, fitFracErr, np.sqrt(fitFracCorrected.std_dev**2 + fitFracErr**2)]
            if printTruth:
                fitFracTableLine.append(nominalDF[fitFracName + "_True"][0])
                
                # Writing to .tex file

                tableFile.write(r'    ' + writeTableLine(fitFracTableLine) + '\n')
                tableFile.write(r'    \hline' + '\n')
                
                # Saving corrected fit parameters to dictionary outside of loop
                correctedFitParams[ampName] = ak.values_astype([ampTableLine[6]], "float")
                correctedFitParams[phaseName] = ak.values_astype([phaseTableLine[6]], "float")
                correctedFitParams[fitFracName] = ak.values_astype([fitFracCorrected.nominal_value], "float")
        tableFile.write(r'    \hline' + '\n')
        tableFile.write(r'\end{tabular}')
    print(f"Fit systematics table saved to {tableSavePath}")
    # Writing corrected fit parameters to .root file
    correctedFitParams['iExpt'] = ak.values_astype([0], np.int32)
    correctedRootFile = uproot.recreate(correctedParamsPath)
    correctedRootFile["fitResults"] = correctedFitParams
    print(f"Corrected fit results saved to {correctedParamsPath}")